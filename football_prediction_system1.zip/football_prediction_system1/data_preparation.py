"""
Makine Öğrenmesi için Veri Hazırlama Modülü
Bu modül, kaliteli liglerden 2000+ veri toplayarak ML modellerini eğitmek için hazırlar.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import logging
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc

from database_models import DatabaseManager, League, Team, Fixture, FixtureStatistics, TeamStatistics, FeatureEngineering
from data_integration import DataIntegration
from high_quality_leagues_filter import HighQualityLeaguesFilter

# Logging konfigürasyonu
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataPreparation:
    """
    Makine öğrenmesi için veri hazırlama sınıfı
    """
    
    def __init__(self, api_key: str, database_url: str):
        """
        Veri hazırlama sistemini başlatır
        
        Args:
            api_key (str): API-Football anahtarı
            database_url (str): Veritabanı bağlantı URL'i
        """
        self.db_manager = DatabaseManager(database_url)
        self.data_integration = DataIntegration(api_key, database_url)
        self.leagues_filter = HighQualityLeaguesFilter('/home/ubuntu/upload/all_leagues.txt')
        
        # Kaliteli ligleri al
        self.quality_leagues = self.leagues_filter.get_filtered_leagues_by_priority()
        
    def collect_training_data(self, target_matches: int = 2000, season: int = 2025) -> bool:
        """
        Eğitim için hedef sayıda maç verisi toplar
        
        Args:
            target_matches (int): Hedef maç sayısı
            season (int): Sezon
            
        Returns:
            bool: Başarı durumu
        """
        try:
            logger.info(f"Hedef {target_matches} maç verisi toplanıyor...")
            
            # Öncelik sırasına göre ligleri işle
            collected_matches = 0
            
            # 1. En yüksek öncelik ligleri
            priority_1_leagues = [league['league_id'] for league in self.quality_leagues.get(1, [])]
            if priority_1_leagues:
                logger.info("En yüksek öncelik ligleri işleniyor...")
                if self._collect_from_leagues(priority_1_leagues, season):
                    collected_matches = self._count_collected_matches()
                    logger.info(f"Öncelik 1'den {collected_matches} maç toplandı")
            
            # 2. Yüksek öncelik ligleri (hedef sayıya ulaşılmadıysa)
            if collected_matches < target_matches:
                priority_2_leagues = [league['league_id'] for league in self.quality_leagues.get(2, [])]
                if priority_2_leagues:
                    logger.info("Yüksek öncelik ligleri işleniyor...")
                    if self._collect_from_leagues(priority_2_leagues, season):
                        collected_matches = self._count_collected_matches()
                        logger.info(f"Öncelik 2'den toplam {collected_matches} maç toplandı")
            
            # 3. Normal öncelik ligleri (hedef sayıya ulaşılmadıysa)
            if collected_matches < target_matches:
                priority_3_leagues = [league['league_id'] for league in self.quality_leagues.get(3, [])[:20]]  # İlk 20 lig
                if priority_3_leagues:
                    logger.info("Normal öncelik ligleri işleniyor...")
                    if self._collect_from_leagues(priority_3_leagues, season):
                        collected_matches = self._count_collected_matches()
                        logger.info(f"Öncelik 3'den toplam {collected_matches} maç toplandı")
            
            final_count = self._count_collected_matches()
            logger.info(f"Toplam {final_count} maç verisi toplandı")
            
            if final_count >= target_matches * 0.8:  # %80'ine ulaştıysa başarılı
                logger.info("✅ Hedef veri toplama başarılı")
                return True
            else:
                logger.warning(f"Hedef {target_matches} maça ulaşılamadı, {final_count} maç toplandı")
                return False
                
        except Exception as e:
            logger.error(f"Veri toplama hatası: {e}")
            return False
    
    def _collect_from_leagues(self, league_ids: List[int], season: int) -> bool:
        """
        Belirtilen liglerden veri toplar
        
        Args:
            league_ids: Lig ID'leri
            season: Sezon
            
        Returns:
            bool: Başarı durumu
        """
        try:
            # Ligleri senkronize et
            if not self.data_integration.sync_leagues(season):
                logger.warning("Lig senkronizasyonu başarısız")
            
            # Takımları senkronize et
            if not self.data_integration.sync_teams(league_ids, season):
                logger.warning("Takım senkronizasyonu başarısız")
            
            # Maçları senkronize et
            if not self.data_integration.sync_fixtures(league_ids, season):
                logger.warning("Maç senkronizasyonu başarısız")
                return False
            
            # Takım istatistiklerini senkronize et
            if not self.data_integration.sync_team_statistics(league_ids, season):
                logger.warning("Takım istatistik senkronizasyonu başarısız")
            
            return True
            
        except Exception as e:
            logger.error(f"Lig veri toplama hatası: {e}")
            return False
    
    def _count_collected_matches(self) -> int:
        """
        Toplanan maç sayısını döndürür
        
        Returns:
            int: Maç sayısı
        """
        try:
            session = self.db_manager.get_session()
            count = session.query(Fixture).count()
            session.close()
            return count
        except Exception as e:
            logger.error(f"Maç sayma hatası: {e}")
            return 0
    
    def prepare_feature_matrix(self) -> pd.DataFrame:
        """
        Makine öğrenmesi için özellik matrisi hazırlar
        
        Returns:
            pd.DataFrame: Özellik matrisi
        """
        try:
            session = self.db_manager.get_session()
            
            # Tamamlanmış maçları al
            completed_fixtures = session.query(Fixture).filter(
                Fixture.status == 'FT'
            ).all()
            
            if not completed_fixtures:
                logger.warning("Tamamlanmış maç bulunamadı")
                return pd.DataFrame()
            
            features_list = []
            
            for fixture in completed_fixtures:
                try:
                    # Her maç için özellik vektörü oluştur
                    feature_vector = self._create_feature_vector(fixture, session)
                    if feature_vector:
                        features_list.append(feature_vector)
                        
                except Exception as e:
                    logger.warning(f"Özellik vektörü oluşturma hatası (Maç {fixture.fixture_id}): {e}")
                    continue
            
            session.close()
            
            if not features_list:
                logger.warning("Hiç özellik vektörü oluşturulamadı")
                return pd.DataFrame()
            
            features_df = pd.DataFrame(features_list)
            logger.info(f"Özellik matrisi hazırlandı: {len(features_df)} maç, {len(features_df.columns)} özellik")
            
            return features_df
            
        except Exception as e:
            logger.error(f"Özellik matrisi hazırlama hatası: {e}")
            return pd.DataFrame()
    
    def _create_feature_vector(self, fixture: Fixture, session: Session) -> Optional[Dict]:
        """
        Tek bir maç için özellik vektörü oluşturur
        
        Args:
            fixture: Maç objesi
            session: Veritabanı oturumu
            
        Returns:
            Dict: Özellik vektörü
        """
        try:
            # Temel maç bilgileri
            feature_vector = {
                'fixture_id': fixture.fixture_id,
                'home_team_id': fixture.home_team_id,
                'away_team_id': fixture.away_team_id,
                'league_id': fixture.league_id,
                'season': fixture.season,
                'date': fixture.date,
                
                # Hedef değişkenler
                'home_goals': fixture.home_goals or 0,
                'away_goals': fixture.away_goals or 0,
                'total_goals': (fixture.home_goals or 0) + (fixture.away_goals or 0),
                'match_result': self._get_match_result(fixture.home_goals, fixture.away_goals),
                'over_2_5': 1 if ((fixture.home_goals or 0) + (fixture.away_goals or 0)) > 2.5 else 0,
                'both_teams_score': 1 if (fixture.home_goals or 0) > 0 and (fixture.away_goals or 0) > 0 else 0
            }
            
            # Ev sahibi takım özellikleri
            home_features = self._get_team_features(fixture.home_team_id, fixture.league_id, fixture.season, session, 'home')
            feature_vector.update(home_features)
            
            # Deplasman takımı özellikleri
            away_features = self._get_team_features(fixture.away_team_id, fixture.league_id, fixture.season, session, 'away')
            feature_vector.update(away_features)
            
            # Head-to-head özellikleri
            h2h_features = self._get_h2h_features(fixture.home_team_id, fixture.away_team_id, fixture.date, session)
            feature_vector.update(h2h_features)
            
            # Form özellikleri
            home_form = self._get_team_form(fixture.home_team_id, fixture.date, session, 'home')
            away_form = self._get_team_form(fixture.away_team_id, fixture.date, session, 'away')
            feature_vector.update(home_form)
            feature_vector.update(away_form)
            
            return feature_vector
            
        except Exception as e:
            logger.warning(f"Özellik vektörü oluşturma hatası: {e}")
            return None
    
    def _get_match_result(self, home_goals: Optional[int], away_goals: Optional[int]) -> int:
        """
        Maç sonucunu kodlar (1: Ev sahibi galip, 0: Beraberlik, 2: Deplasman galip)
        
        Args:
            home_goals: Ev sahibi golleri
            away_goals: Deplasman golleri
            
        Returns:
            int: Kodlanmış sonuç
        """
        if home_goals is None or away_goals is None:
            return -1
        
        if home_goals > away_goals:
            return 1  # Ev sahibi galip
        elif home_goals == away_goals:
            return 0  # Beraberlik
        else:
            return 2  # Deplasman galip
    
    def _get_team_features(self, team_id: int, league_id: int, season: int, session: Session, prefix: str) -> Dict:
        """
        Takım özelliklerini getirir
        
        Args:
            team_id: Takım ID
            league_id: Lig ID
            season: Sezon
            session: Veritabanı oturumu
            prefix: Özellik ön eki (home/away)
            
        Returns:
            Dict: Takım özellikleri
        """
        try:
            # Takım istatistiklerini al
            team_stats = session.query(TeamStatistics).filter(
                and_(
                    TeamStatistics.team_id == team_id,
                    TeamStatistics.league_id == league_id,
                    TeamStatistics.season == season
                )
            ).first()
            
            if not team_stats:
                # Varsayılan değerler
                return {
                    f'{prefix}_matches_played': 0,
                    f'{prefix}_wins': 0,
                    f'{prefix}_draws': 0,
                    f'{prefix}_losses': 0,
                    f'{prefix}_goals_for': 0,
                    f'{prefix}_goals_against': 0,
                    f'{prefix}_goals_for_avg': 0.0,
                    f'{prefix}_goals_against_avg': 0.0,
                    f'{prefix}_win_rate': 0.0,
                    f'{prefix}_elo_rating': 1500.0
                }
            
            # Oranları hesapla
            matches_played = team_stats.matches_played or 1
            win_rate = (team_stats.wins or 0) / matches_played
            goals_for_avg = (team_stats.goals_for or 0) / matches_played
            goals_against_avg = (team_stats.goals_against or 0) / matches_played
            
            return {
                f'{prefix}_matches_played': team_stats.matches_played or 0,
                f'{prefix}_wins': team_stats.wins or 0,
                f'{prefix}_draws': team_stats.draws or 0,
                f'{prefix}_losses': team_stats.losses or 0,
                f'{prefix}_goals_for': team_stats.goals_for or 0,
                f'{prefix}_goals_against': team_stats.goals_against or 0,
                f'{prefix}_goals_for_avg': goals_for_avg,
                f'{prefix}_goals_against_avg': goals_against_avg,
                f'{prefix}_win_rate': win_rate,
                f'{prefix}_elo_rating': team_stats.elo_rating or 1500.0,
                f'{prefix}_clean_sheets': team_stats.clean_sheets or 0,
                f'{prefix}_failed_to_score': team_stats.failed_to_score or 0
            }
            
        except Exception as e:
            logger.warning(f"Takım özellik hatası: {e}")
            return {}
    
    def _get_h2h_features(self, home_team_id: int, away_team_id: int, match_date: datetime, session: Session) -> Dict:
        """
        Head-to-head özelliklerini getirir
        
        Args:
            home_team_id: Ev sahibi takım ID
            away_team_id: Deplasman takım ID
            match_date: Maç tarihi
            session: Veritabanı oturumu
            
        Returns:
            Dict: H2H özellikleri
        """
        try:
            # Son 5 karşılaşmayı al
            h2h_matches = session.query(Fixture).filter(
                and_(
                    or_(
                        and_(Fixture.home_team_id == home_team_id, Fixture.away_team_id == away_team_id),
                        and_(Fixture.home_team_id == away_team_id, Fixture.away_team_id == home_team_id)
                    ),
                    Fixture.date < match_date,
                    Fixture.status == 'FT'
                )
            ).order_by(desc(Fixture.date)).limit(5).all()
            
            if not h2h_matches:
                return {
                    'h2h_matches': 0,
                    'h2h_home_wins': 0,
                    'h2h_draws': 0,
                    'h2h_away_wins': 0,
                    'h2h_goals_for_avg': 0.0,
                    'h2h_goals_against_avg': 0.0
                }
            
            home_wins = 0
            draws = 0
            away_wins = 0
            total_goals_for = 0
            total_goals_against = 0
            
            for match in h2h_matches:
                if match.home_team_id == home_team_id:
                    # Ev sahibi olarak oynadı
                    home_goals = match.home_goals or 0
                    away_goals = match.away_goals or 0
                    total_goals_for += home_goals
                    total_goals_against += away_goals
                    
                    if home_goals > away_goals:
                        home_wins += 1
                    elif home_goals == away_goals:
                        draws += 1
                    else:
                        away_wins += 1
                else:
                    # Deplasman olarak oynadı
                    home_goals = match.home_goals or 0
                    away_goals = match.away_goals or 0
                    total_goals_for += away_goals
                    total_goals_against += home_goals
                    
                    if away_goals > home_goals:
                        home_wins += 1
                    elif away_goals == home_goals:
                        draws += 1
                    else:
                        away_wins += 1
            
            match_count = len(h2h_matches)
            
            return {
                'h2h_matches': match_count,
                'h2h_home_wins': home_wins,
                'h2h_draws': draws,
                'h2h_away_wins': away_wins,
                'h2h_goals_for_avg': total_goals_for / match_count,
                'h2h_goals_against_avg': total_goals_against / match_count
            }
            
        except Exception as e:
            logger.warning(f"H2H özellik hatası: {e}")
            return {}
    
    def _get_team_form(self, team_id: int, match_date: datetime, session: Session, prefix: str) -> Dict:
        """
        Takım formunu getirir (son 5 maç)
        
        Args:
            team_id: Takım ID
            match_date: Maç tarihi
            session: Veritabanı oturumu
            prefix: Özellik ön eki
            
        Returns:
            Dict: Form özellikleri
        """
        try:
            # Son 5 maçı al
            recent_matches = session.query(Fixture).filter(
                and_(
                    or_(Fixture.home_team_id == team_id, Fixture.away_team_id == team_id),
                    Fixture.date < match_date,
                    Fixture.status == 'FT'
                )
            ).order_by(desc(Fixture.date)).limit(5).all()
            
            if not recent_matches:
                return {
                    f'{prefix}_form_points': 0,
                    f'{prefix}_form_wins': 0,
                    f'{prefix}_form_draws': 0,
                    f'{prefix}_form_losses': 0,
                    f'{prefix}_form_goals_for': 0,
                    f'{prefix}_form_goals_against': 0
                }
            
            points = 0
            wins = 0
            draws = 0
            losses = 0
            goals_for = 0
            goals_against = 0
            
            for match in recent_matches:
                if match.home_team_id == team_id:
                    # Ev sahibi olarak oynadı
                    home_goals = match.home_goals or 0
                    away_goals = match.away_goals or 0
                    goals_for += home_goals
                    goals_against += away_goals
                    
                    if home_goals > away_goals:
                        wins += 1
                        points += 3
                    elif home_goals == away_goals:
                        draws += 1
                        points += 1
                    else:
                        losses += 1
                else:
                    # Deplasman olarak oynadı
                    home_goals = match.home_goals or 0
                    away_goals = match.away_goals or 0
                    goals_for += away_goals
                    goals_against += home_goals
                    
                    if away_goals > home_goals:
                        wins += 1
                        points += 3
                    elif away_goals == home_goals:
                        draws += 1
                        points += 1
                    else:
                        losses += 1
            
            return {
                f'{prefix}_form_points': points,
                f'{prefix}_form_wins': wins,
                f'{prefix}_form_draws': draws,
                f'{prefix}_form_losses': losses,
                f'{prefix}_form_goals_for': goals_for,
                f'{prefix}_form_goals_against': goals_against
            }
            
        except Exception as e:
            logger.warning(f"Form özellik hatası: {e}")
            return {}
    
    def export_training_data(self, output_path: str) -> bool:
        """
        Eğitim verilerini CSV'ye export eder
        
        Args:
            output_path: Çıktı dosyası yolu
            
        Returns:
            bool: Başarı durumu
        """
        try:
            features_df = self.prepare_feature_matrix()
            
            if features_df.empty:
                logger.warning("Export edilecek eğitim verisi yok")
                return False
            
            features_df.to_csv(output_path, index=False, encoding='utf-8-sig')
            logger.info(f"Eğitim verileri export edildi: {output_path}")
            logger.info(f"Veri boyutu: {len(features_df)} maç, {len(features_df.columns)} özellik")
            
            return True
            
        except Exception as e:
            logger.error(f"Export hatası: {e}")
            return False


def test_data_preparation():
    """
    Veri hazırlama sistemini test eder
    """
    api_key = "6e8bb5327emsh6512ba4710242aap152911jsnc708554057f0"
    database_url = "postgresql://football_user:football123@localhost/football_prediction_db"
    
    try:
        print("=== Veri Hazırlama Sistemi Testi ===\n")
        
        # Veri hazırlama sistemini oluştur
        data_prep = DataPreparation(api_key, database_url)
        
        # Mevcut veri durumunu kontrol et
        print("1. Mevcut veri durumu:")
        current_matches = data_prep._count_collected_matches()
        print(f"   - Mevcut maç sayısı: {current_matches}")
        
        # Kaliteli ligleri göster
        print("\n2. Kaliteli lig grupları:")
        for priority, leagues in data_prep.quality_leagues.items():
            priority_names = {1: "En Yüksek", 2: "Yüksek", 3: "Normal"}
            print(f"   - {priority_names[priority]} Öncelik: {len(leagues)} lig")
        
        # Eğer yeterli veri yoksa topla
        if current_matches < 1000:
            print(f"\n3. Hedef 2000 maç için veri toplama başlatılıyor...")
            if data_prep.collect_training_data(target_matches=2000):
                print("✅ Veri toplama başarılı")
                final_matches = data_prep._count_collected_matches()
                print(f"   - Toplanan maç sayısı: {final_matches}")
            else:
                print("❌ Veri toplama başarısız")
        else:
            print(f"\n3. Yeterli veri mevcut ({current_matches} maç)")
        
        # Özellik matrisi hazırla
        print("\n4. Özellik matrisi hazırlanıyor...")
        features_df = data_prep.prepare_feature_matrix()
        
        if not features_df.empty:
            print(f"✅ Özellik matrisi hazırlandı")
            print(f"   - Maç sayısı: {len(features_df)}")
            print(f"   - Özellik sayısı: {len(features_df.columns)}")
            print(f"   - Örnek özellikler: {list(features_df.columns[:10])}")
            
            # Export et
            print("\n5. Eğitim verileri export ediliyor...")
            if data_prep.export_training_data('/home/ubuntu/football_prediction_system/training_data.csv'):
                print("✅ Export başarılı")
            else:
                print("❌ Export başarısız")
        else:
            print("❌ Özellik matrisi hazırlanamadı")
        
        print("\n✅ Veri hazırlama sistemi testi başarılı!")
        
    except Exception as e:
        print(f"❌ Test hatası: {e}")


if __name__ == "__main__":
    test_data_preparation()

