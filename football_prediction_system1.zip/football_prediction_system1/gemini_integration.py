"""
Google Gemini API Entegrasyonu
Bu modül, Gemini 2.0 Flash modelini kullanarak haber analizi, sakatlık raporları ve model yorumlaması yapar.
"""

import requests
import json
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime

# Logging konfigürasyonu
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class GeminiIntegration:
    """
    Google Gemini API entegrasyon sınıfı
    """
    
    def __init__(self, api_key: str):
        """
        Gemini entegrasyonunu başlatır
        
        Args:
            api_key (str): Google Gemini API anahtarı
        """
        self.api_key = api_key
        self.base_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
        self.headers = {
            'Content-Type': 'application/json',
            'X-goog-api-key': self.api_key
        }
    
    def _make_request(self, prompt: str, max_tokens: int = 1000) -> Optional[str]:
        """
        Gemini API'sine istek gönderir
        
        Args:
            prompt (str): Gönderilecek prompt
            max_tokens (int): Maksimum token sayısı
            
        Returns:
            str: API yanıtı
        """
        try:
            payload = {
                "contents": [
                    {
                        "parts": [
                            {
                                "text": prompt
                            }
                        ]
                    }
                ],
                "generationConfig": {
                    "maxOutputTokens": max_tokens,
                    "temperature": 0.7
                }
            }
            
            response = requests.post(
                self.base_url,
                headers=self.headers,
                data=json.dumps(payload),
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                if 'candidates' in result and len(result['candidates']) > 0:
                    content = result['candidates'][0]['content']['parts'][0]['text']
                    logger.info("Gemini API isteği başarılı")
                    return content.strip()
                else:
                    logger.warning("Gemini API yanıtında içerik bulunamadı")
                    return None
            else:
                logger.error(f"Gemini API hatası: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Gemini API istek hatası: {e}")
            return None
    
    def analyze_team_news(self, team_name: str, news_text: str) -> Dict[str, Any]:
        """
        Takım haberlerini analiz eder
        
        Args:
            team_name (str): Takım adı
            news_text (str): Haber metni
            
        Returns:
            Dict: Analiz sonuçları
        """
        try:
            prompt = f"""
            Futbol takımı: {team_name}
            Haber metni: {news_text}
            
            Bu haberi analiz et ve aşağıdaki bilgileri JSON formatında ver:
            {{
                "sentiment": "positive/negative/neutral",
                "impact_on_performance": "high/medium/low",
                "key_players_mentioned": ["oyuncu1", "oyuncu2"],
                "injury_concerns": ["sakatlık1", "sakatlık2"],
                "tactical_changes": "taktiksel değişiklikler",
                "confidence_factor": 0.0-1.0,
                "summary": "kısa özet"
            }}
            
            Sadece JSON formatında yanıt ver, başka açıklama ekleme.
            """
            
            response = self._make_request(prompt)
            
            if response:
                try:
                    # JSON parse et
                    analysis = json.loads(response)
                    analysis['timestamp'] = datetime.now().isoformat()
                    analysis['team_name'] = team_name
                    return analysis
                except json.JSONDecodeError:
                    logger.warning("Gemini yanıtı JSON formatında değil")
                    return {
                        "sentiment": "neutral",
                        "impact_on_performance": "low",
                        "confidence_factor": 0.5,
                        "summary": response[:200] if response else "Analiz yapılamadı",
                        "timestamp": datetime.now().isoformat(),
                        "team_name": team_name
                    }
            else:
                return {
                    "sentiment": "neutral",
                    "impact_on_performance": "low",
                    "confidence_factor": 0.0,
                    "summary": "Haber analizi yapılamadı",
                    "timestamp": datetime.now().isoformat(),
                    "team_name": team_name
                }
                
        except Exception as e:
            logger.error(f"Haber analizi hatası: {e}")
            return {}
    
    def analyze_injury_report(self, team_name: str, injury_text: str) -> Dict[str, Any]:
        """
        Sakatlık raporlarını analiz eder
        
        Args:
            team_name (str): Takım adı
            injury_text (str): Sakatlık raporu metni
            
        Returns:
            Dict: Sakatlık analizi
        """
        try:
            prompt = f"""
            Takım: {team_name}
            Sakatlık raporu: {injury_text}
            
            Bu sakatlık raporunu analiz et ve JSON formatında ver:
            {{
                "injured_players": [
                    {{
                        "name": "oyuncu adı",
                        "position": "pozisyon",
                        "injury_type": "sakatlık türü",
                        "severity": "hafif/orta/ağır",
                        "expected_return": "tahmini dönüş süresi",
                        "impact_on_team": "takıma etkisi"
                    }}
                ],
                "total_impact_score": 0.0-1.0,
                "key_positions_affected": ["pozisyon1", "pozisyon2"],
                "team_strength_reduction": 0.0-1.0,
                "summary": "genel değerlendirme"
            }}
            
            Sadece JSON formatında yanıt ver.
            """
            
            response = self._make_request(prompt)
            
            if response:
                try:
                    analysis = json.loads(response)
                    analysis['timestamp'] = datetime.now().isoformat()
                    analysis['team_name'] = team_name
                    return analysis
                except json.JSONDecodeError:
                    return {
                        "total_impact_score": 0.5,
                        "team_strength_reduction": 0.3,
                        "summary": response[:200] if response else "Sakatlık analizi yapılamadı",
                        "timestamp": datetime.now().isoformat(),
                        "team_name": team_name
                    }
            else:
                return {
                    "total_impact_score": 0.0,
                    "team_strength_reduction": 0.0,
                    "summary": "Sakatlık raporu analizi yapılamadı",
                    "timestamp": datetime.now().isoformat(),
                    "team_name": team_name
                }
                
        except Exception as e:
            logger.error(f"Sakatlık analizi hatası: {e}")
            return {}
    
    def interpret_prediction_results(self, home_team: str, away_team: str, 
                                   model_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Model tahmin sonuçlarını yorumlar
        
        Args:
            home_team (str): Ev sahibi takım
            away_team (str): Deplasman takımı
            model_results (Dict): Model sonuçları
            
        Returns:
            Dict: Yorumlama sonuçları
        """
        try:
            prompt = f"""
            Maç: {home_team} vs {away_team}
            Model sonuçları: {json.dumps(model_results, indent=2)}
            
            Bu futbol maçı tahmin sonuçlarını analiz et ve şu formatta yorumla:
            {{
                "match_prediction": "ev sahibi galip/beraberlik/deplasman galip",
                "confidence_level": "yüksek/orta/düşük",
                "key_factors": [
                    "faktör 1",
                    "faktör 2",
                    "faktör 3"
                ],
                "risk_analysis": "risk değerlendirmesi",
                "betting_recommendation": {{
                    "primary_bet": "ana bahis önerisi",
                    "alternative_bets": ["alternatif 1", "alternatif 2"],
                    "avoid_bets": ["kaçınılacak bahisler"]
                }},
                "explanation": "detaylı açıklama",
                "probability_breakdown": {{
                    "home_win": "yüzde",
                    "draw": "yüzde", 
                    "away_win": "yüzde"
                }}
            }}
            
            Sadece JSON formatında yanıt ver.
            """
            
            response = self._make_request(prompt, max_tokens=1500)
            
            if response:
                try:
                    interpretation = json.loads(response)
                    interpretation['timestamp'] = datetime.now().isoformat()
                    interpretation['match'] = f"{home_team} vs {away_team}"
                    return interpretation
                except json.JSONDecodeError:
                    return {
                        "match_prediction": "belirsiz",
                        "confidence_level": "düşük",
                        "explanation": response[:300] if response else "Yorumlama yapılamadı",
                        "timestamp": datetime.now().isoformat(),
                        "match": f"{home_team} vs {away_team}"
                    }
            else:
                return {
                    "match_prediction": "belirsiz",
                    "confidence_level": "düşük",
                    "explanation": "Model sonuçları yorumlanamadı",
                    "timestamp": datetime.now().isoformat(),
                    "match": f"{home_team} vs {away_team}"
                }
                
        except Exception as e:
            logger.error(f"Sonuç yorumlama hatası: {e}")
            return {}
    
    def generate_match_preview(self, home_team: str, away_team: str, 
                             team_stats: Dict[str, Any], 
                             h2h_history: List[Dict]) -> str:
        """
        Maç önizlemesi oluşturur
        
        Args:
            home_team (str): Ev sahibi takım
            away_team (str): Deplasman takımı
            team_stats (Dict): Takım istatistikleri
            h2h_history (List): Karşılaşma geçmişi
            
        Returns:
            str: Maç önizlemesi
        """
        try:
            prompt = f"""
            Maç: {home_team} vs {away_team}
            
            Takım İstatistikleri:
            {json.dumps(team_stats, indent=2)}
            
            Karşılaşma Geçmişi:
            {json.dumps(h2h_history, indent=2)}
            
            Bu bilgileri kullanarak profesyonel bir maç önizlemesi yaz. Şunları içersin:
            - Takımların mevcut durumu
            - Güçlü ve zayıf yönleri
            - Karşılaşma geçmişi analizi
            - Kilit oyuncular
            - Taktiksel beklentiler
            - Tahmin ve öneriler
            
            Türkçe olarak, spor gazeteciliği tarzında yaz.
            """
            
            response = self._make_request(prompt, max_tokens=2000)
            
            if response:
                return response
            else:
                return f"{home_team} vs {away_team} maçı için önizleme oluşturulamadı."
                
        except Exception as e:
            logger.error(f"Maç önizlemesi hatası: {e}")
            return f"Maç önizlemesi oluşturulurken hata: {e}"
    
    def test_connection(self) -> bool:
        """
        Gemini API bağlantısını test eder
        
        Returns:
            bool: Bağlantı durumu
        """
        try:
            test_prompt = "Merhaba, bu bir test mesajıdır. Kısaca yanıtla."
            response = self._make_request(test_prompt)
            
            if response:
                logger.info("Gemini API bağlantısı başarılı")
                return True
            else:
                logger.error("Gemini API bağlantısı başarısız")
                return False
                
        except Exception as e:
            logger.error(f"Gemini API test hatası: {e}")
            return False


def test_gemini_integration():
    """
    Gemini entegrasyonunu test eder
    """
    api_key = "AIzaSyBvgeHCoujarKyyHCAvmFTMyH8Inl6nf4w"
    
    try:
        print("=== Gemini API Entegrasyon Testi ===\n")
        
        # Gemini entegrasyonu oluştur
        gemini = GeminiIntegration(api_key)
        
        # Bağlantıyı test et
        print("1. API bağlantısı test ediliyor...")
        if gemini.test_connection():
            print("✅ Gemini API bağlantısı başarılı")
        else:
            print("❌ Gemini API bağlantısı başarısız")
            return
        
        # Haber analizi testi
        print("\n2. Haber analizi testi:")
        sample_news = """
        Manchester United'ın yıldız oyuncusu Marcus Rashford, antrenmanda yaşadığı 
        sakatlık nedeniyle bu hafta sonu oynanacak maçta yer alamayacak. Takımın 
        teknik direktörü, oyuncunun 2-3 hafta sahalardan uzak kalacağını açıkladı.
        """
        
        news_analysis = gemini.analyze_team_news("Manchester United", sample_news)
        if news_analysis:
            print("✅ Haber analizi başarılı")
            print(f"   - Sentiment: {news_analysis.get('sentiment', 'N/A')}")
            print(f"   - Performans etkisi: {news_analysis.get('impact_on_performance', 'N/A')}")
            print(f"   - Özet: {news_analysis.get('summary', 'N/A')[:100]}...")
        else:
            print("❌ Haber analizi başarısız")
        
        # Sakatlık analizi testi
        print("\n3. Sakatlık analizi testi:")
        injury_report = """
        Takımda 3 oyuncu sakatlık yaşıyor: Kaleci hafif parmak sakatlığı, 
        orta saha oyuncusu kas gerginliği, forvet oyuncusu diz sakatlığı.
        """
        
        injury_analysis = gemini.analyze_injury_report("Arsenal", injury_report)
        if injury_analysis:
            print("✅ Sakatlık analizi başarılı")
            print(f"   - Toplam etki skoru: {injury_analysis.get('total_impact_score', 'N/A')}")
            print(f"   - Takım gücü azalması: {injury_analysis.get('team_strength_reduction', 'N/A')}")
        else:
            print("❌ Sakatlık analizi başarısız")
        
        # Model yorumlama testi
        print("\n4. Model sonuç yorumlama testi:")
        sample_results = {
            "home_win_probability": 0.45,
            "draw_probability": 0.25,
            "away_win_probability": 0.30,
            "over_2_5_goals": 0.65,
            "both_teams_score": 0.70
        }
        
        interpretation = gemini.interpret_prediction_results(
            "Liverpool", "Chelsea", sample_results
        )
        if interpretation:
            print("✅ Model yorumlama başarılı")
            print(f"   - Tahmin: {interpretation.get('match_prediction', 'N/A')}")
            print(f"   - Güven seviyesi: {interpretation.get('confidence_level', 'N/A')}")
        else:
            print("❌ Model yorumlama başarısız")
        
        print("\n✅ Gemini API entegrasyon testi başarılı!")
        
    except Exception as e:
        print(f"❌ Test hatası: {e}")


if __name__ == "__main__":
    test_gemini_integration()

