"""
Futbol Maç Analiz ve Tahmin Sistemi - Veri Toplama Modülü
Bu modül, referans projelerden ilham alarak geliştirilmiş kapsamlı veri toplama sistemidir.

Referans Projeler:
- motapinto/football-classification-predications: Supervised learning modelleri
- krishnakartik1/LSTM-footballMatchWinner: LSTM tabanlı tahmin sistemi
- jakeyk11/football-data-analytics: Kapsamlı futbol veri analizi araçları
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Optional, Any, Tuple
import time
import json
from api_football_client import APIFootballClient

# Logging konfigürasyonu
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FootballDataCollector:
    """
    Futbol verilerini toplayan ve işleyen ana sınıf
    Referans projelerden ilham alınarak geliştirilmiştir
    """
    
    def __init__(self, api_key: str):
        """
        Veri toplayıcıyı başlatır
        
        Args:
            api_key (str): API-Football anahtarı
        """
        self.api_client = APIFootballClient(api_key)
        self.current_season = 2025
        
        # Ana Avrupa ligleri (referans projelerden)
        self.major_leagues = {
            'Premier League': 39,
            'La Liga': 140,
            'Serie A': 135,
            'Bundesliga': 78,
            'Ligue 1': 61,
            'Champions League': 2,
            'Europa League': 3
        }
        
        # Veri önbelleği
        self.cache = {
            'teams': {},
            'fixtures': {},
            'statistics': {},
            'h2h': {}
        }
    
    def collect_league_teams(self, league_id: int, season: int = None) -> pd.DataFrame:
        """
        Belirli bir lig için takım verilerini toplar
        
        Args:
            league_id (int): Lig ID'si
            season (int): Sezon (varsayılan: mevcut sezon)
            
        Returns:
            pd.DataFrame: Takım verileri
        """
        if season is None:
            season = self.current_season
            
        cache_key = f"{league_id}_{season}"
        if cache_key in self.cache['teams']:
            logger.info(f"Cache'den takım verileri alınıyor: {cache_key}")
            return self.cache['teams'][cache_key]
        
        try:
            teams_data = self.api_client.get_teams(league_id=league_id, season=season)
            
            teams_df = pd.DataFrame()
            for team_data in teams_data:
                team_info = {
                    'team_id': team_data['team']['id'],
                    'team_name': team_data['team']['name'],
                    'team_code': team_data['team']['code'],
                    'country': team_data['team']['country'],
                    'founded': team_data['team']['founded'],
                    'venue_id': team_data['venue']['id'],
                    'venue_name': team_data['venue']['name'],
                    'venue_capacity': team_data['venue']['capacity'],
                    'league_id': league_id,
                    'season': season
                }
                teams_df = pd.concat([teams_df, pd.DataFrame([team_info])], ignore_index=True)
            
            self.cache['teams'][cache_key] = teams_df
            logger.info(f"Toplanan takım sayısı: {len(teams_df)}")
            return teams_df
            
        except Exception as e:
            logger.error(f"Takım verileri toplanırken hata: {e}")
            return pd.DataFrame()
    
    def collect_fixtures(self, league_id: int, season: int = None, 
                        date_from: str = None, date_to: str = None) -> pd.DataFrame:
        """
        Maç fikstürlerini toplar
        
        Args:
            league_id (int): Lig ID'si
            season (int): Sezon
            date_from (str): Başlangıç tarihi (YYYY-MM-DD)
            date_to (str): Bitiş tarihi (YYYY-MM-DD)
            
        Returns:
            pd.DataFrame: Maç verileri
        """
        if season is None:
            season = self.current_season
            
        try:
            fixtures_data = self.api_client.get_fixtures(
                league_id=league_id, 
                season=season
            )
            
            fixtures_df = pd.DataFrame()
            for fixture in fixtures_data:
                fixture_info = {
                    'fixture_id': fixture['fixture']['id'],
                    'date': fixture['fixture']['date'],
                    'status': fixture['fixture']['status']['short'],
                    'round': fixture['league']['round'],
                    'home_team_id': fixture['teams']['home']['id'],
                    'home_team_name': fixture['teams']['home']['name'],
                    'away_team_id': fixture['teams']['away']['id'],
                    'away_team_name': fixture['teams']['away']['name'],
                    'home_goals': fixture['goals']['home'],
                    'away_goals': fixture['goals']['away'],
                    'league_id': league_id,
                    'season': season
                }
                fixtures_df = pd.concat([fixtures_df, pd.DataFrame([fixture_info])], ignore_index=True)
            
            # Tarih filtreleme
            if date_from or date_to:
                fixtures_df['date'] = pd.to_datetime(fixtures_df['date'])
                if date_from:
                    fixtures_df = fixtures_df[fixtures_df['date'] >= date_from]
                if date_to:
                    fixtures_df = fixtures_df[fixtures_df['date'] <= date_to]
            
            logger.info(f"Toplanan maç sayısı: {len(fixtures_df)}")
            return fixtures_df
            
        except Exception as e:
            logger.error(f"Maç verileri toplanırken hata: {e}")
            return pd.DataFrame()
    
    def collect_team_statistics(self, team_id: int, league_id: int, season: int = None) -> Dict[str, Any]:
        """
        Takım istatistiklerini toplar (motapinto projesinden ilham)
        
        Args:
            team_id (int): Takım ID'si
            league_id (int): Lig ID'si
            season (int): Sezon
            
        Returns:
            Dict: Takım istatistikleri
        """
        if season is None:
            season = self.current_season
            
        try:
            stats = self.api_client.get_team_statistics(league_id, season, team_id)
            
            if not stats:
                return {}
            
            # İstatistikleri düzenle
            processed_stats = {
                'team_id': team_id,
                'league_id': league_id,
                'season': season,
                'matches_played': stats.get('fixtures', {}).get('played', {}).get('total', 0),
                'wins': stats.get('fixtures', {}).get('wins', {}).get('total', 0),
                'draws': stats.get('fixtures', {}).get('draws', {}).get('total', 0),
                'losses': stats.get('fixtures', {}).get('loses', {}).get('total', 0),
                'goals_for': stats.get('goals', {}).get('for', {}).get('total', {}).get('total', 0),
                'goals_against': stats.get('goals', {}).get('against', {}).get('total', {}).get('total', 0),
                'clean_sheets': stats.get('clean_sheet', {}).get('total', 0),
                'failed_to_score': stats.get('failed_to_score', {}).get('total', 0)
            }
            
            return processed_stats
            
        except Exception as e:
            logger.error(f"Takım istatistikleri toplanırken hata: {e}")
            return {}
    
    def collect_head_to_head(self, team1_id: int, team2_id: int, last_matches: int = 10) -> pd.DataFrame:
        """
        İki takım arasındaki geçmiş maçları toplar
        
        Args:
            team1_id (int): İlk takım ID'si
            team2_id (int): İkinci takım ID'si
            last_matches (int): Son kaç maç
            
        Returns:
            pd.DataFrame: Head-to-head verileri
        """
        cache_key = f"{team1_id}_{team2_id}_{last_matches}"
        if cache_key in self.cache['h2h']:
            return self.cache['h2h'][cache_key]
        
        try:
            h2h_data = self.api_client.get_head_to_head(team1_id, team2_id, last=last_matches)
            
            h2h_df = pd.DataFrame()
            for match in h2h_data:
                match_info = {
                    'fixture_id': match['fixture']['id'],
                    'date': match['fixture']['date'],
                    'home_team_id': match['teams']['home']['id'],
                    'home_team_name': match['teams']['home']['name'],
                    'away_team_id': match['teams']['away']['id'],
                    'away_team_name': match['teams']['away']['name'],
                    'home_goals': match['goals']['home'],
                    'away_goals': match['goals']['away'],
                    'league_name': match['league']['name']
                }
                h2h_df = pd.concat([h2h_df, pd.DataFrame([match_info])], ignore_index=True)
            
            self.cache['h2h'][cache_key] = h2h_df
            logger.info(f"H2H maç sayısı: {len(h2h_df)}")
            return h2h_df
            
        except Exception as e:
            logger.error(f"H2H verileri toplanırken hata: {e}")
            return pd.DataFrame()
    
    def collect_match_statistics(self, fixture_id: int) -> Dict[str, Any]:
        """
        Belirli bir maçın detaylı istatistiklerini toplar
        
        Args:
            fixture_id (int): Maç ID'si
            
        Returns:
            Dict: Maç istatistikleri
        """
        try:
            stats = self.api_client.get_fixture_statistics(fixture_id)
            
            if not stats or len(stats) < 2:
                return {}
            
            home_stats = stats[0]['statistics'] if stats[0]['team']['id'] else {}
            away_stats = stats[1]['statistics'] if len(stats) > 1 and stats[1]['team']['id'] else {}
            
            # İstatistikleri düzenle
            processed_stats = {
                'fixture_id': fixture_id,
                'home_team_id': stats[0]['team']['id'] if stats[0]['team']['id'] else None,
                'away_team_id': stats[1]['team']['id'] if len(stats) > 1 and stats[1]['team']['id'] else None,
                'home_shots_total': self._extract_stat_value(home_stats, 'Shots on Goal'),
                'away_shots_total': self._extract_stat_value(away_stats, 'Shots on Goal'),
                'home_possession': self._extract_stat_value(home_stats, 'Ball Possession'),
                'away_possession': self._extract_stat_value(away_stats, 'Ball Possession'),
                'home_corners': self._extract_stat_value(home_stats, 'Corner Kicks'),
                'away_corners': self._extract_stat_value(away_stats, 'Corner Kicks'),
                'home_fouls': self._extract_stat_value(home_stats, 'Fouls'),
                'away_fouls': self._extract_stat_value(away_stats, 'Fouls'),
                'home_yellow_cards': self._extract_stat_value(home_stats, 'Yellow Cards'),
                'away_yellow_cards': self._extract_stat_value(away_stats, 'Yellow Cards'),
                'home_red_cards': self._extract_stat_value(home_stats, 'Red Cards'),
                'away_red_cards': self._extract_stat_value(away_stats, 'Red Cards')
            }
            
            return processed_stats
            
        except Exception as e:
            logger.error(f"Maç istatistikleri toplanırken hata: {e}")
            return {}
    
    def _extract_stat_value(self, stats_list: List[Dict], stat_name: str) -> Optional[int]:
        """
        İstatistik listesinden belirli bir değeri çıkarır
        
        Args:
            stats_list (List[Dict]): İstatistik listesi
            stat_name (str): İstatistik adı
            
        Returns:
            Optional[int]: İstatistik değeri
        """
        for stat in stats_list:
            if stat.get('type') == stat_name:
                value = stat.get('value')
                if value is not None:
                    # Yüzde değerlerini temizle
                    if isinstance(value, str) and '%' in value:
                        return int(value.replace('%', ''))
                    try:
                        return int(value)
                    except (ValueError, TypeError):
                        return None
        return None
    
    def calculate_team_form(self, team_id: int, fixtures_df: pd.DataFrame, last_n_matches: int = 5) -> Dict[str, Any]:
        """
        Takım formunu hesaplar (krishnakartik1 projesinden ilham)
        
        Args:
            team_id (int): Takım ID'si
            fixtures_df (pd.DataFrame): Maç verileri
            last_n_matches (int): Son kaç maç
            
        Returns:
            Dict: Form verileri
        """
        # Takımın maçlarını filtrele
        team_matches = fixtures_df[
            (fixtures_df['home_team_id'] == team_id) | 
            (fixtures_df['away_team_id'] == team_id)
        ].copy()
        
        # Tarihe göre sırala ve son N maçı al
        team_matches['date'] = pd.to_datetime(team_matches['date'])
        team_matches = team_matches.sort_values('date', ascending=False).head(last_n_matches)
        
        if len(team_matches) == 0:
            return {'wins': 0, 'draws': 0, 'losses': 0, 'points': 0, 'goals_for': 0, 'goals_against': 0}
        
        wins = draws = losses = 0
        goals_for = goals_against = 0
        
        for _, match in team_matches.iterrows():
            if match['home_team_id'] == team_id:
                # Ev sahibi
                home_goals = match['home_goals'] or 0
                away_goals = match['away_goals'] or 0
                goals_for += home_goals
                goals_against += away_goals
                
                if home_goals > away_goals:
                    wins += 1
                elif home_goals == away_goals:
                    draws += 1
                else:
                    losses += 1
            else:
                # Deplasman
                home_goals = match['home_goals'] or 0
                away_goals = match['away_goals'] or 0
                goals_for += away_goals
                goals_against += home_goals
                
                if away_goals > home_goals:
                    wins += 1
                elif away_goals == home_goals:
                    draws += 1
                else:
                    losses += 1
        
        points = wins * 3 + draws * 1
        
        return {
            'wins': wins,
            'draws': draws,
            'losses': losses,
            'points': points,
            'goals_for': goals_for,
            'goals_against': goals_against,
            'goal_difference': goals_for - goals_against,
            'matches_played': len(team_matches)
        }
    
    def collect_comprehensive_match_data(self, fixture_id: int) -> Dict[str, Any]:
        """
        Bir maç için kapsamlı veri toplar (jakeyk11 projesinden ilham)
        
        Args:
            fixture_id (int): Maç ID'si
            
        Returns:
            Dict: Kapsamlı maç verileri
        """
        try:
            # Temel maç bilgileri
            fixtures = self.api_client.get_fixtures()
            match_info = None
            for fixture in fixtures:
                if fixture['fixture']['id'] == fixture_id:
                    match_info = fixture
                    break
            
            if not match_info:
                logger.error(f"Maç bulunamadı: {fixture_id}")
                return {}
            
            # Maç istatistikleri
            match_stats = self.collect_match_statistics(fixture_id)
            
            # Takım bilgileri
            home_team_id = match_info['teams']['home']['id']
            away_team_id = match_info['teams']['away']['id']
            
            # Head-to-head
            h2h_data = self.collect_head_to_head(home_team_id, away_team_id, last_matches=5)
            
            # Kapsamlı veri yapısı
            comprehensive_data = {
                'match_info': {
                    'fixture_id': fixture_id,
                    'date': match_info['fixture']['date'],
                    'status': match_info['fixture']['status']['short'],
                    'home_team': {
                        'id': home_team_id,
                        'name': match_info['teams']['home']['name']
                    },
                    'away_team': {
                        'id': away_team_id,
                        'name': match_info['teams']['away']['name']
                    },
                    'score': {
                        'home': match_info['goals']['home'],
                        'away': match_info['goals']['away']
                    }
                },
                'match_statistics': match_stats,
                'head_to_head': h2h_data.to_dict('records') if not h2h_data.empty else [],
                'predictions': self.api_client.get_predictions(fixture_id)
            }
            
            return comprehensive_data
            
        except Exception as e:
            logger.error(f"Kapsamlı maç verileri toplanırken hata: {e}")
            return {}
    
    def save_data_to_csv(self, data: pd.DataFrame, filename: str, directory: str = "data") -> bool:
        """
        Verileri CSV dosyasına kaydeder
        
        Args:
            data (pd.DataFrame): Kaydedilecek veriler
            filename (str): Dosya adı
            directory (str): Dizin adı
            
        Returns:
            bool: Başarı durumu
        """
        try:
            import os
            if not os.path.exists(directory):
                os.makedirs(directory)
            
            filepath = os.path.join(directory, filename)
            data.to_csv(filepath, index=False)
            logger.info(f"Veriler kaydedildi: {filepath}")
            return True
            
        except Exception as e:
            logger.error(f"Veri kaydetme hatası: {e}")
            return False


# Test fonksiyonu
def test_data_collector():
    """
    Veri toplayıcıyı test eder
    """
    api_key = "6e8bb5327emsh6512ba4710242aap152911jsnc708554057f0"
    collector = FootballDataCollector(api_key)
    
    try:
        print("Premier League takımları toplanıyor...")
        teams = collector.collect_league_teams(39, 2025)  # Premier League 2025
        print(f"Toplanan takım sayısı: {len(teams)}")
        
        if not teams.empty:
            print("\nİlk 5 takım:")
            print(teams.head())
            
            # İlk takım için istatistikleri al
            first_team_id = teams.iloc[0]['team_id']
            print(f"\nTakım istatistikleri alınıyor (ID: {first_team_id})...")
            stats = collector.collect_team_statistics(first_team_id, 39, 2025)
            print("İstatistikler:", stats)
        
        print("\nVeri toplayıcı testi başarılı!")
        
    except Exception as e:
        print(f"Test hatası: {e}")


if __name__ == "__main__":
    test_data_collector()

