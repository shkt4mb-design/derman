"""
Tüm Ligleri Parse Eden ve Sisteme Entegre Eden Modül
Bu modül, kullanıcının sağladığı tüm ligleri parse eder ve sisteme entegre eder.
"""

import pandas as pd
import re
from typing import Dict, List, Tuple
import logging

# Logging konfigürasyonu
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AllLeaguesParser:
    """
    Tüm ligleri parse eden ve kategorize eden sınıf
    """
    
    def __init__(self, leagues_file_path: str):
        """
        Parser'ı başlatır
        
        Args:
            leagues_file_path (str): Ligler dosyasının yolu
        """
        self.leagues_file_path = leagues_file_path
        self.leagues_data = []
        self.leagues_by_country = {}
        self.leagues_by_category = {}
        
    def parse_leagues_file(self) -> pd.DataFrame:
        """
        Ligler dosyasını parse eder
        
        Returns:
            pd.DataFrame: Parse edilmiş lig verileri
        """
        try:
            with open(self.leagues_file_path, 'r', encoding='utf-8') as file:
                content = file.read()
            
            # Her satırı parse et
            lines = content.strip().split('\n')
            
            for line in lines:
                if line.strip():
                    # Regex ile ID, Lig adı ve Ülke bilgisini çıkar
                    match = re.match(r'ID:\s*(\d+),\s*Lig:\s*([^,]+),\s*Ülke:\s*(.+)', line.strip())
                    if match:
                        league_id = int(match.group(1))
                        league_name = match.group(2).strip()
                        country = match.group(3).strip()
                        
                        league_info = {
                            'league_id': league_id,
                            'league_name': league_name,
                            'country': country
                        }
                        
                        self.leagues_data.append(league_info)
            
            # DataFrame'e dönüştür
            leagues_df = pd.DataFrame(self.leagues_data)
            logger.info(f"Toplam {len(leagues_df)} lig parse edildi")
            
            return leagues_df
            
        except Exception as e:
            logger.error(f"Ligler dosyası parse edilirken hata: {e}")
            return pd.DataFrame()
    
    def categorize_leagues(self, leagues_df: pd.DataFrame) -> Dict[str, Dict]:
        """
        Ligleri kategorilere ayırır
        
        Args:
            leagues_df (pd.DataFrame): Lig verileri
            
        Returns:
            Dict: Kategorize edilmiş ligler
        """
        categories = {
            'major_european': {
                'name': 'Ana Avrupa Ligleri',
                'leagues': [],
                'criteria': ['Premier League', 'La Liga', 'Serie A', 'Bundesliga', 'Ligue 1']
            },
            'european_cups': {
                'name': 'Avrupa Kupaları',
                'leagues': [],
                'criteria': ['Champions League', 'Europa League', 'UEFA']
            },
            'world_cups': {
                'name': 'Dünya Kupaları ve Uluslararası Turnuvalar',
                'leagues': [],
                'criteria': ['World Cup', 'Euro Championship', 'Copa America', 'Asian Cup', 'Africa Cup']
            },
            'national_leagues': {
                'name': 'Ulusal Ligler',
                'leagues': [],
                'criteria': []  # Diğer tüm ulusal ligler
            },
            'youth_leagues': {
                'name': 'Gençlik Ligleri',
                'leagues': [],
                'criteria': ['U17', 'U19', 'U20', 'U21', 'U23', 'Youth', 'Junior']
            },
            'women_leagues': {
                'name': 'Kadın Ligleri',
                'leagues': [],
                'criteria': ['Women', 'Femenil', 'Feminine', 'Frauen', 'Damallsvenskan']
            },
            'cup_competitions': {
                'name': 'Kupa Müsabakaları',
                'leagues': [],
                'criteria': ['Cup', 'Copa', 'Coupe', 'Coppa', 'Pokal']
            }
        }
        
        # Her ligi kategorize et
        for _, league in leagues_df.iterrows():
            league_name = league['league_name']
            country = league['country']
            categorized = False
            
            # Ana kategorileri kontrol et
            for category_key, category_info in categories.items():
                if category_key == 'national_leagues':
                    continue  # Bu kategoriyi en son kontrol edeceğiz
                
                for criteria in category_info['criteria']:
                    if criteria.lower() in league_name.lower():
                        categories[category_key]['leagues'].append(league.to_dict())
                        categorized = True
                        break
                
                if categorized:
                    break
            
            # Eğer hiçbir kategoriye girmemişse ulusal liglere ekle
            if not categorized:
                categories['national_leagues']['leagues'].append(league.to_dict())
        
        # Ülkelere göre grupla
        self.leagues_by_country = leagues_df.groupby('country').apply(lambda x: x.to_dict('records')).to_dict()
        
        # İstatistikleri logla
        for category_key, category_info in categories.items():
            logger.info(f"{category_info['name']}: {len(category_info['leagues'])} lig")
        
        return categories
    
    def get_priority_leagues(self) -> List[Dict]:
        """
        Öncelikli ligleri döndürür (tahmin sistemi için)
        
        Returns:
            List[Dict]: Öncelikli ligler
        """
        priority_leagues = [
            # Ana Avrupa Ligleri
            {'league_id': 39, 'name': 'Premier League', 'country': 'England', 'priority': 1},
            {'league_id': 140, 'name': 'La Liga', 'country': 'Spain', 'priority': 1},
            {'league_id': 135, 'name': 'Serie A', 'country': 'Italy', 'priority': 1},
            {'league_id': 78, 'name': 'Bundesliga', 'country': 'Germany', 'priority': 1},
            {'league_id': 61, 'name': 'Ligue 1', 'country': 'France', 'priority': 1},
            
            # Avrupa Kupaları
            {'league_id': 2, 'name': 'UEFA Champions League', 'country': 'World', 'priority': 1},
            {'league_id': 3, 'name': 'UEFA Europa League', 'country': 'World', 'priority': 1},
            
            # Diğer Önemli Ligler
            {'league_id': 88, 'name': 'Eredivisie', 'country': 'Netherlands', 'priority': 2},
            {'league_id': 94, 'name': 'Primeira Liga', 'country': 'Portugal', 'priority': 2},
            {'league_id': 144, 'name': 'Jupiler Pro League', 'country': 'Belgium', 'priority': 2},
            {'league_id': 203, 'name': 'Süper Lig', 'country': 'Turkey', 'priority': 2},
            {'league_id': 71, 'name': 'Serie A', 'country': 'Brazil', 'priority': 2},
            {'league_id': 128, 'name': 'Liga Profesional Argentina', 'country': 'Argentina', 'priority': 2},
            
            # Uluslararası Turnuvalar
            {'league_id': 1, 'name': 'World Cup', 'country': 'World', 'priority': 1},
            {'league_id': 4, 'name': 'Euro Championship', 'country': 'World', 'priority': 1},
            {'league_id': 9, 'name': 'Copa America', 'country': 'World', 'priority': 1},
        ]
        
        return priority_leagues
    
    def get_leagues_by_country(self, country: str) -> List[Dict]:
        """
        Belirli bir ülkenin liglerini döndürür
        
        Args:
            country (str): Ülke adı
            
        Returns:
            List[Dict]: Ülkenin ligleri
        """
        return self.leagues_by_country.get(country, [])
    
    def search_leagues(self, search_term: str) -> List[Dict]:
        """
        Lig adında arama yapar
        
        Args:
            search_term (str): Arama terimi
            
        Returns:
            List[Dict]: Bulunan ligler
        """
        results = []
        search_term_lower = search_term.lower()
        
        for league in self.leagues_data:
            if (search_term_lower in league['league_name'].lower() or 
                search_term_lower in league['country'].lower()):
                results.append(league)
        
        return results
    
    def get_league_statistics(self) -> Dict[str, int]:
        """
        Lig istatistiklerini döndürür
        
        Returns:
            Dict: İstatistikler
        """
        leagues_df = pd.DataFrame(self.leagues_data)
        
        stats = {
            'total_leagues': len(leagues_df),
            'total_countries': leagues_df['country'].nunique(),
            'leagues_by_country': leagues_df['country'].value_counts().to_dict(),
            'world_competitions': len(leagues_df[leagues_df['country'] == 'World'])
        }
        
        return stats
    
    def export_leagues_to_csv(self, output_path: str) -> bool:
        """
        Ligleri CSV dosyasına export eder
        
        Args:
            output_path (str): Çıktı dosyası yolu
            
        Returns:
            bool: Başarı durumu
        """
        try:
            leagues_df = pd.DataFrame(self.leagues_data)
            leagues_df.to_csv(output_path, index=False, encoding='utf-8')
            logger.info(f"Ligler CSV'ye export edildi: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"CSV export hatası: {e}")
            return False


def test_leagues_parser():
    """
    Ligler parser'ını test eder
    """
    parser = AllLeaguesParser('/home/ubuntu/upload/all_leagues.txt')
    
    try:
        # Ligleri parse et
        print("Ligler parse ediliyor...")
        leagues_df = parser.parse_leagues_file()
        print(f"Toplam {len(leagues_df)} lig parse edildi")
        
        # İlk 10 ligi göster
        print("\nİlk 10 lig:")
        print(leagues_df.head(10))
        
        # Kategorize et
        print("\nLigler kategorize ediliyor...")
        categories = parser.categorize_leagues(leagues_df)
        
        print("\nKategori istatistikleri:")
        for category_key, category_info in categories.items():
            print(f"- {category_info['name']}: {len(category_info['leagues'])} lig")
        
        # Öncelikli ligleri göster
        print("\nÖncelikli ligler:")
        priority_leagues = parser.get_priority_leagues()
        for league in priority_leagues[:10]:
            print(f"- {league['name']} ({league['country']}) - Öncelik: {league['priority']}")
        
        # İstatistikleri göster
        print("\nGenel istatistikler:")
        stats = parser.get_league_statistics()
        print(f"- Toplam lig sayısı: {stats['total_leagues']}")
        print(f"- Toplam ülke sayısı: {stats['total_countries']}")
        print(f"- Dünya müsabakaları: {stats['world_competitions']}")
        
        # En çok lige sahip ülkeler
        print("\nEn çok lige sahip ülkeler (ilk 10):")
        country_counts = sorted(stats['leagues_by_country'].items(), key=lambda x: x[1], reverse=True)
        for country, count in country_counts[:10]:
            print(f"- {country}: {count} lig")
        
        # CSV'ye export et
        parser.export_leagues_to_csv('/home/ubuntu/football_prediction_system/all_leagues.csv')
        
        print("\nLigler parser testi başarılı!")
        
    except Exception as e:
        print(f"Test hatası: {e}")


if __name__ == "__main__":
    test_leagues_parser()

