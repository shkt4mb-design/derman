"""
API-Football entegrasyonu için Python modülü
Bu modül, API-Football v3 API'si ile etkileşim kurmak için gerekli fonksiyonları içerir.
"""

import requests
import json
import time
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import logging

# Logging konfigürasyonu
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class APIFootballClient:
    """
    API-Football v3 API'si ile etkileşim kurmak için client sınıfı
    """
    
    def __init__(self, api_key: str):
        """
        API client'ı başlatır
        
        Args:
            api_key (str): RapidAPI anahtarı
        """
        self.api_key = api_key
        self.base_url = "https://api-football-v1.p.rapidapi.com/v3"
        self.headers = {
            'x-rapidapi-host': 'api-football-v1.p.rapidapi.com',
            'x-rapidapi-key': api_key
        }
        self.rate_limit_delay = 1  # API rate limiting için bekleme süresi (saniye)
    
    def _make_request(self, endpoint: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        """
        API'ye istek gönderir ve yanıtı döndürür
        
        Args:
            endpoint (str): API endpoint'i
            params (Dict, optional): İstek parametreleri
            
        Returns:
            Dict: API yanıtı
            
        Raises:
            Exception: API isteği başarısız olursa
        """
        url = f"{self.base_url}/{endpoint}"
        
        try:
            # Rate limiting için bekleme
            time.sleep(self.rate_limit_delay)
            
            response = requests.get(url, headers=self.headers, params=params)
            response.raise_for_status()
            
            data = response.json()
            
            # API yanıtını kontrol et
            if 'errors' in data and data['errors']:
                logger.error(f"API Error: {data['errors']}")
                raise Exception(f"API Error: {data['errors']}")
            
            logger.info(f"API request successful: {endpoint}")
            return data
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed: {e}")
            raise Exception(f"API request failed: {e}")
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            raise Exception(f"Invalid JSON response: {e}")
    
    def get_timezones(self) -> List[str]:
        """
        Mevcut zaman dilimlerini getirir
        
        Returns:
            List[str]: Zaman dilimleri listesi
        """
        data = self._make_request("timezone")
        return data.get('response', [])
    
    def get_predictions(self, fixture_id: int) -> Dict[str, Any]:
        """
        Belirli bir maç için tahminleri getirir
        
        Args:
            fixture_id (int): Maç ID'si
            
        Returns:
            Dict: Maç tahminleri ve istatistikleri
        """
        params = {'fixture': fixture_id}
        data = self._make_request("predictions", params)
        return data.get('response', [])
    
    def get_head_to_head(self, team1_id: int, team2_id: int, 
                        date: Optional[str] = None, 
                        league_id: Optional[int] = None,
                        season: Optional[int] = None,
                        last: Optional[int] = None,
                        next: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        İki takım arasındaki geçmiş maçları getirir
        
        Args:
            team1_id (int): İlk takım ID'si
            team2_id (int): İkinci takım ID'si
            date (str, optional): Tarih (yyyy-mm-dd formatında)
            league_id (int, optional): Lig ID'si
            season (int, optional): Sezon
            last (int, optional): Son X maç
            next (int, optional): Sonraki X maç
            
        Returns:
            List[Dict]: Geçmiş maçlar listesi
        """
        params = {'h2h': f"{team1_id}-{team2_id}"}
        
        if date:
            params['date'] = date
        if league_id:
            params['league'] = league_id
        if season:
            params['season'] = season
        if last:
            params['last'] = last
        if next:
            params['next'] = next
            
        data = self._make_request("fixtures/headtohead", params)
        return data.get('response', [])
    
    def get_team_statistics(self, league_id: int, season: int, team_id: int,
                           date: Optional[str] = None) -> Dict[str, Any]:
        """
        Takım istatistiklerini getirir
        
        Args:
            league_id (int): Lig ID'si
            season (int): Sezon
            team_id (int): Takım ID'si
            date (str, optional): Limit tarihi (yyyy-mm-dd formatında)
            
        Returns:
            Dict: Takım istatistikleri
        """
        params = {
            'league': league_id,
            'season': season,
            'team': team_id
        }
        
        if date:
            params['date'] = date
            
        data = self._make_request("teams/statistics", params)
        return data.get('response', {})
    
    def get_seasons(self) -> List[int]:
        """
        Mevcut sezonları getirir
        
        Returns:
            List[int]: Sezonlar listesi
        """
        data = self._make_request("leagues/seasons")
        return data.get('response', [])
    
    def get_fixture_statistics(self, fixture_id: int, 
                              team_id: Optional[int] = None,
                              stat_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Maç istatistiklerini getirir
        
        Args:
            fixture_id (int): Maç ID'si
            team_id (int, optional): Takım ID'si
            stat_type (str, optional): İstatistik türü
            
        Returns:
            List[Dict]: Maç istatistikleri
        """
        params = {'fixture': fixture_id}
        
        if team_id:
            params['team'] = team_id
        if stat_type:
            params['type'] = stat_type
            
        data = self._make_request("fixtures/statistics", params)
        return data.get('response', [])
    
    def get_player_statistics(self, player_id: int, season: Optional[int] = None,
                             team_id: Optional[int] = None,
                             league_id: Optional[int] = None,
                             search: Optional[str] = None,
                             page: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Oyuncu istatistiklerini getirir
        
        Args:
            player_id (int): Oyuncu ID'si
            season (int, optional): Sezon
            team_id (int, optional): Takım ID'si
            league_id (int, optional): Lig ID'si
            search (str, optional): Oyuncu adı (min 4 karakter)
            page (int, optional): Sayfa numarası
            
        Returns:
            List[Dict]: Oyuncu istatistikleri
        """
        params = {'id': player_id}
        
        if season:
            params['season'] = season
        if team_id:
            params['team'] = team_id
        if league_id:
            params['league'] = league_id
        if search:
            params['search'] = search
        if page:
            params['page'] = page
            
        data = self._make_request("players", params)
        return data.get('response', [])
    
    def get_fixture_lineups(self, fixture_id: int,
                           team_id: Optional[int] = None,
                           player_id: Optional[int] = None,
                           lineup_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Maç dizilişlerini getirir
        
        Args:
            fixture_id (int): Maç ID'si
            team_id (int, optional): Takım ID'si
            player_id (int, optional): Oyuncu ID'si
            lineup_type (str, optional): Diziliş türü
            
        Returns:
            List[Dict]: Maç dizilişleri
        """
        params = {'fixture': fixture_id}
        
        if team_id:
            params['team'] = team_id
        if player_id:
            params['player'] = player_id
        if lineup_type:
            params['type'] = lineup_type
            
        data = self._make_request("fixtures/lineups", params)
        return data.get('response', [])
    
    def get_player_trophies(self, player_id: int,
                           coach_id: Optional[int] = None,
                           players: Optional[str] = None,
                           coaches: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Oyuncu kupalarını getirir
        
        Args:
            player_id (int): Oyuncu ID'si
            coach_id (int, optional): Koç ID'si
            players (str, optional): Maksimum 20 oyuncu ID'si
            coaches (str, optional): Maksimum 20 koç ID'si
            
        Returns:
            List[Dict]: Oyuncu kupaları
        """
        params = {'player': player_id}
        
        if coach_id:
            params['coach'] = coach_id
        if players:
            params['players'] = players
        if coaches:
            params['coachs'] = coaches
            
        data = self._make_request("trophies", params)
        return data.get('response', [])
    
    def get_live_odds(self, fixture_id: Optional[int] = None,
                     league_id: Optional[int] = None,
                     bet_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Canlı maç oranlarını getirir
        
        Args:
            fixture_id (int, optional): Maç ID'si
            league_id (int, optional): Lig ID'si
            bet_id (int, optional): Bahis ID'si
            
        Returns:
            List[Dict]: Canlı maç oranları
        """
        params = {}
        
        if fixture_id:
            params['fixture'] = fixture_id
        if league_id:
            params['league'] = league_id
        if bet_id:
            params['bet'] = bet_id
            
        data = self._make_request("odds/live", params)
        return data.get('response', [])
    
    def get_sidelined_players(self, player_id: Optional[int] = None,
                             team_id: Optional[int] = None,
                             fixture_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Sakatlanan oyuncuları getirir
        
        Args:
            player_id (int, optional): Oyuncu ID'si
            team_id (int, optional): Takım ID'si
            fixture_id (int, optional): Maç ID'si
            
        Returns:
            List[Dict]: Sakatlanan oyuncular
        """
        params = {}
        
        if player_id:
            params['player'] = player_id
        if team_id:
            params['team'] = team_id
        if fixture_id:
            params['fixture'] = fixture_id
            
        data = self._make_request("sidelined", params)
        return data.get('response', [])
    
    def get_fixtures(self, league_id: Optional[int] = None,
                    season: Optional[int] = None,
                    team_id: Optional[int] = None,
                    date: Optional[str] = None,
                    status: Optional[str] = None,
                    live: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Maç fikstürlerini getirir
        
        Args:
            league_id (int, optional): Lig ID'si
            season (int, optional): Sezon
            team_id (int, optional): Takım ID'si
            date (str, optional): Tarih (yyyy-mm-dd formatında)
            status (str, optional): Maç durumu
            live (str, optional): Canlı maçlar için 'all'
            
        Returns:
            List[Dict]: Maç fikstürleri
        """
        params = {}
        
        if league_id:
            params['league'] = league_id
        if season:
            params['season'] = season
        if team_id:
            params['team'] = team_id
        if date:
            params['date'] = date
        if status:
            params['status'] = status
        if live:
            params['live'] = live
            
        data = self._make_request("fixtures", params)
        return data.get('response', [])
    
    def get_leagues(self, league_id: Optional[int] = None,
                   country: Optional[str] = None,
                   season: Optional[int] = None,
                   team_id: Optional[int] = None,
                   type_: Optional[str] = None,
                   current: Optional[str] = None,
                   search: Optional[str] = None,
                   last: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Ligleri getirir
        
        Args:
            league_id (int, optional): Lig ID'si
            country (str, optional): Ülke adı
            season (int, optional): Sezon
            team_id (int, optional): Takım ID'si
            type_ (str, optional): Lig türü
            current (str, optional): Mevcut sezon için 'true'
            search (str, optional): Arama terimi
            last (int, optional): Son X lig
            
        Returns:
            List[Dict]: Ligler
        """
        params = {}
        
        if league_id:
            params['id'] = league_id
        if country:
            params['country'] = country
        if season:
            params['season'] = season
        if team_id:
            params['team'] = team_id
        if type_:
            params['type'] = type_
        if current:
            params['current'] = current
        if search:
            params['search'] = search
        if last:
            params['last'] = last
            
        data = self._make_request("leagues", params)
        return data.get('response', [])
    
    def get_teams(self, team_id: Optional[int] = None,
                 league_id: Optional[int] = None,
                 season: Optional[int] = None,
                 country: Optional[str] = None,
                 code: Optional[str] = None,
                 venue_id: Optional[int] = None,
                 search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Takımları getirir
        
        Args:
            team_id (int, optional): Takım ID'si
            league_id (int, optional): Lig ID'si
            season (int, optional): Sezon
            country (str, optional): Ülke adı
            code (str, optional): Takım kodu
            venue_id (int, optional): Stadyum ID'si
            search (str, optional): Arama terimi
            
        Returns:
            List[Dict]: Takımlar
        """
        params = {}
        
        if team_id:
            params['id'] = team_id
        if league_id:
            params['league'] = league_id
        if season:
            params['season'] = season
        if country:
            params['country'] = country
        if code:
            params['code'] = code
        if venue_id:
            params['venue'] = venue_id
        if search:
            params['search'] = search
            
        data = self._make_request("teams", params)
        return data.get('response', [])


# Örnek kullanım ve test fonksiyonları
def test_api_client():
    """
    API client'ı test eder
    """
    # API anahtarı - gerçek kullanımda environment variable'dan alınmalı
    api_key = "6e8bb5327emsh6512ba4710242aap152911jsnc708554057f0"
    
    client = APIFootballClient(api_key)
    
    try:
        # Zaman dilimlerini test et
        print("Testing timezones...")
        timezones = client.get_timezones()
        print(f"Found {len(timezones)} timezones")
        
        # Sezonları test et
        print("\nTesting seasons...")
        seasons = client.get_seasons()
        print(f"Found {len(seasons)} seasons")
        
        # İngiliz Premier Ligi için takımları test et
        print("\nTesting teams for Premier League...")
        teams = client.get_teams(league_id=39, season=2025)  # Premier League 2025
        print(f"Found {len(teams)} teams in Premier League 2025")
        
        if teams:
            # İlk iki takım arasında head-to-head test et
            team1_id = teams[0]['team']['id']
            team2_id = teams[1]['team']['id'] if len(teams) > 1 else teams[0]['team']['id']
            
            print(f"\nTesting head-to-head between team {team1_id} and {team2_id}...")
            h2h = client.get_head_to_head(team1_id, team2_id, last=5)
            print(f"Found {len(h2h)} head-to-head matches")
            
        print("\nAPI client test completed successfully!")
        
    except Exception as e:
        print(f"API client test failed: {e}")


if __name__ == "__main__":
    test_api_client()

