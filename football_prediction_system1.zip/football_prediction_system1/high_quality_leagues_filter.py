"""
Yüksek Kaliteli Ligler Filtresi
Bu modül, %80+ gerçek maç bahsi verecek kaliteli ligleri seçer.
Kadın ligleri, gençlik ligleri ve düşük kaliteli ligleri filtreler.
"""

import pandas as pd
import re
from typing import Dict, List, Set, Any
import logging

# Logging konfigürasyonu
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class HighQualityLeaguesFilter:
    """
    Yüksek kaliteli ligleri filtreleme sınıfı
    """
    
    def __init__(self, leagues_file_path: str):
        """
        Filtreyi başlatır
        
        Args:
            leagues_file_path (str): Ligler dosyasının yolu
        """
        self.leagues_file_path = leagues_file_path
        
        # Filtrelenecek kelimeler (düşük kalite)
        self.exclude_keywords = {
            # Kadın ligleri
            'women', 'feminine', 'femenil', 'frauen', 'damallsvenskan', 'dames',
            'feminino', 'femminile', 'kobiet', 'naisten', 'kvinner', 'vrouwen',
            
            # Gençlik ligleri
            'u17', 'u19', 'u20', 'u21', 'u23', 'youth', 'junior', 'juvenil',
            'juniores', 'giovanili', 'młodzież', 'nuorten', 'ungdom',
            
            # Düşük kalite ligler
            'amateur', 'amador', 'dilettanti', 'amatör', 'harrastaja',
            'reserve', 'reserva', 'riserve', 'rezerwy', 'varareservi',
            
            # Kupa müsabakaları (bazıları)
            'friendly', 'amistoso', 'amichevole', 'towarzyski', 'ystävyys',
            'winter', 'summer', 'verano', 'inverno', 'zima', 'talvi',
            
            # Düşük seviye
            'regional', 'district', 'county', 'provincial', 'local',
            'municipal', 'community', 'village', 'town'
        }
        
        # Yüksek kaliteli ülkeler (ana futbol ülkeleri)
        self.high_quality_countries = {
            'England', 'Spain', 'Italy', 'Germany', 'France', 'Netherlands',
            'Portugal', 'Belgium', 'Turkey', 'Russia', 'Ukraine', 'Greece',
            'Scotland', 'Austria', 'Switzerland', 'Czech-Republic', 'Poland',
            'Croatia', 'Serbia', 'Denmark', 'Sweden', 'Norway', 'Finland',
            'Romania', 'Bulgaria', 'Hungary', 'Slovakia', 'Slovenia',
            'Bosnia-Herzegovina', 'North-Macedonia', 'Montenegro', 'Albania',
            'Moldova', 'Latvia', 'Lithuania', 'Estonia', 'Belarus',
            'Brazil', 'Argentina', 'Uruguay', 'Chile', 'Colombia', 'Peru',
            'Ecuador', 'Paraguay', 'Bolivia', 'Venezuela',
            'Mexico', 'USA', 'Canada', 'Costa-Rica', 'Honduras', 'Guatemala',
            'El-Salvador', 'Panama', 'Jamaica', 'Trinidad-And-Tobago',
            'Japan', 'South-Korea', 'China', 'Australia', 'Saudi-Arabia',
            'UAE', 'Qatar', 'Iran', 'Iraq', 'Jordan', 'Lebanon', 'Syria',
            'Israel', 'India', 'Thailand', 'Malaysia', 'Singapore', 'Indonesia',
            'South-Africa', 'Egypt', 'Morocco', 'Tunisia', 'Algeria', 'Nigeria',
            'Ghana', 'Ivory-Coast', 'Senegal', 'Cameroon', 'Mali', 'Burkina-Faso'
        }
        
        # Öncelikli ligler (en yüksek kalite)
        self.priority_leagues = {
            # Ana Avrupa Ligleri
            39: {'name': 'Premier League', 'country': 'England', 'priority': 1},
            140: {'name': 'La Liga', 'country': 'Spain', 'priority': 1},
            135: {'name': 'Serie A', 'country': 'Italy', 'priority': 1},
            78: {'name': 'Bundesliga', 'country': 'Germany', 'priority': 1},
            61: {'name': 'Ligue 1', 'country': 'France', 'priority': 1},
            
            # Avrupa Kupaları
            2: {'name': 'UEFA Champions League', 'country': 'World', 'priority': 1},
            3: {'name': 'UEFA Europa League', 'country': 'World', 'priority': 1},
            848: {'name': 'UEFA Europa Conference League', 'country': 'World', 'priority': 1},
            
            # Diğer Önemli Avrupa Ligleri
            88: {'name': 'Eredivisie', 'country': 'Netherlands', 'priority': 2},
            94: {'name': 'Primeira Liga', 'country': 'Portugal', 'priority': 2},
            144: {'name': 'Jupiler Pro League', 'country': 'Belgium', 'priority': 2},
            203: {'name': 'Süper Lig', 'country': 'Turkey', 'priority': 2},
            235: {'name': 'Premier League', 'country': 'Russia', 'priority': 2},
            197: {'name': 'Super League', 'country': 'Greece', 'priority': 2},
            179: {'name': 'Premiership', 'country': 'Scotland', 'priority': 2},
            218: {'name': 'Bundesliga', 'country': 'Austria', 'priority': 2},
            207: {'name': 'Super League', 'country': 'Switzerland', 'priority': 2},
            
            # Güney Amerika
            71: {'name': 'Serie A', 'country': 'Brazil', 'priority': 2},
            128: {'name': 'Liga Profesional Argentina', 'country': 'Argentina', 'priority': 2},
            274: {'name': 'Primera División', 'country': 'Uruguay', 'priority': 2},
            265: {'name': 'Primera División', 'country': 'Chile', 'priority': 2},
            239: {'name': 'Primera A', 'country': 'Colombia', 'priority': 2},
            
            # Kuzey Amerika
            262: {'name': 'Liga MX', 'country': 'Mexico', 'priority': 2},
            253: {'name': 'Major League Soccer', 'country': 'USA', 'priority': 2},
            
            # Asya
            98: {'name': 'J1 League', 'country': 'Japan', 'priority': 2},
            292: {'name': 'K League 1', 'country': 'South-Korea', 'priority': 2},
            169: {'name': 'Super League', 'country': 'China', 'priority': 2},
            188: {'name': 'A-League', 'country': 'Australia', 'priority': 2},
            
            # Orta Doğu
            307: {'name': 'Pro League', 'country': 'Saudi-Arabia', 'priority': 2},
            
            # Afrika
            233: {'name': 'Premier Soccer League', 'country': 'South-Africa', 'priority': 2}
        }
    
    def parse_and_filter_leagues(self) -> pd.DataFrame:
        """
        Ligleri parse eder ve yüksek kaliteli olanları filtreler
        
        Returns:
            pd.DataFrame: Filtrelenmiş lig verileri
        """
        try:
            # Tüm ligleri parse et
            all_leagues = []
            
            with open(self.leagues_file_path, 'r', encoding='utf-8') as file:
                content = file.read()
            
            lines = content.strip().split('\n')
            
            for line in lines:
                if line.strip():
                    match = re.match(r'ID:\s*(\d+),\s*Lig:\s*([^,]+),\s*Ülke:\s*(.+)', line.strip())
                    if match:
                        league_id = int(match.group(1))
                        league_name = match.group(2).strip()
                        country = match.group(3).strip()
                        
                        all_leagues.append({
                            'league_id': league_id,
                            'league_name': league_name,
                            'country': country
                        })
            
            leagues_df = pd.DataFrame(all_leagues)
            logger.info(f"Toplam {len(leagues_df)} lig parse edildi")
            
            # Filtreleme işlemi
            filtered_leagues = self._apply_quality_filters(leagues_df)
            
            logger.info(f"Filtreleme sonrası {len(filtered_leagues)} kaliteli lig kaldı")
            return filtered_leagues
            
        except Exception as e:
            logger.error(f"Lig parse ve filtreleme hatası: {e}")
            return pd.DataFrame()
    
    def _apply_quality_filters(self, leagues_df: pd.DataFrame) -> pd.DataFrame:
        """
        Kalite filtrelerini uygular
        
        Args:
            leagues_df: Tüm ligler
            
        Returns:
            pd.DataFrame: Filtrelenmiş ligler
        """
        filtered_leagues = []
        
        for _, league in leagues_df.iterrows():
            league_name = league['league_name'].lower()
            country = league['country']
            league_id = league['league_id']
            
            # Öncelikli ligleri direkt ekle
            if league_id in self.priority_leagues:
                league_dict = league.to_dict()
                league_dict['priority'] = self.priority_leagues[league_id]['priority']
                league_dict['quality_score'] = 100
                filtered_leagues.append(league_dict)
                continue
            
            # Düşük kalite kelimelerini kontrol et
            if self._contains_exclude_keywords(league_name):
                continue
            
            # Ülke kalitesini kontrol et
            if country not in self.high_quality_countries:
                continue
            
            # Lig adı kalitesini değerlendir
            quality_score = self._calculate_league_quality(league_name, country)
            
            if quality_score >= 60:  # Minimum kalite eşiği
                league_dict = league.to_dict()
                league_dict['priority'] = 3  # Normal öncelik
                league_dict['quality_score'] = quality_score
                filtered_leagues.append(league_dict)
        
        return pd.DataFrame(filtered_leagues)
    
    def _contains_exclude_keywords(self, league_name: str) -> bool:
        """
        Lig adında filtrelenecek kelime var mı kontrol eder
        
        Args:
            league_name: Lig adı
            
        Returns:
            bool: Filtrelenecek kelime var mı
        """
        league_name_lower = league_name.lower()
        
        for keyword in self.exclude_keywords:
            if keyword in league_name_lower:
                return True
        
        return False
    
    def _calculate_league_quality(self, league_name: str, country: str) -> int:
        """
        Lig kalitesini hesaplar
        
        Args:
            league_name: Lig adı
            country: Ülke
            
        Returns:
            int: Kalite skoru (0-100)
        """
        score = 50  # Başlangıç skoru
        
        league_name_lower = league_name.lower()
        
        # Ana lig isimleri
        main_league_keywords = [
            'premier', 'primera', 'serie', 'bundesliga', 'ligue', 'liga',
            'championship', 'division', 'super', 'national', 'professional'
        ]
        
        for keyword in main_league_keywords:
            if keyword in league_name_lower:
                score += 15
                break
        
        # Ülke bazlı bonus
        top_tier_countries = ['England', 'Spain', 'Italy', 'Germany', 'France']
        second_tier_countries = ['Netherlands', 'Portugal', 'Belgium', 'Turkey', 'Brazil', 'Argentina']
        
        if country in top_tier_countries:
            score += 20
        elif country in second_tier_countries:
            score += 15
        else:
            score += 5
        
        # Kupa müsabakaları için bonus
        cup_keywords = ['cup', 'copa', 'coupe', 'coppa', 'pokal']
        if any(keyword in league_name_lower for keyword in cup_keywords):
            score += 10
        
        # Düşük seviye ligler için ceza
        low_tier_keywords = ['3', 'third', 'tercera', 'terza', '2nd', 'second']
        if any(keyword in league_name_lower for keyword in low_tier_keywords):
            score -= 20
        
        return min(100, max(0, score))
    
    def get_filtered_leagues_by_priority(self) -> Dict[int, List[Dict]]:
        """
        Öncelik seviyesine göre gruplandırılmış ligleri döndürür
        
        Returns:
            Dict: Öncelik seviyesine göre ligler
        """
        filtered_leagues = self.parse_and_filter_leagues()
        
        if filtered_leagues.empty:
            return {}
        
        grouped = {
            1: [],  # En yüksek öncelik
            2: [],  # Yüksek öncelik
            3: []   # Normal öncelik
        }
        
        for _, league in filtered_leagues.iterrows():
            priority = league.get('priority', 3)
            grouped[priority].append(league.to_dict())
        
        return grouped
    
    def export_filtered_leagues(self, output_path: str) -> bool:
        """
        Filtrelenmiş ligleri CSV'ye export eder
        
        Args:
            output_path: Çıktı dosyası yolu
            
        Returns:
            bool: Başarı durumu
        """
        try:
            filtered_leagues = self.parse_and_filter_leagues()
            
            if filtered_leagues.empty:
                logger.warning("Export edilecek filtrelenmiş lig yok")
                return False
            
            # Öncelik ve kalite skoruna göre sırala
            filtered_leagues = filtered_leagues.sort_values(
                ['priority', 'quality_score'], 
                ascending=[True, False]
            )
            
            filtered_leagues.to_csv(output_path, index=False, encoding='utf-8-sig')
            logger.info(f"Filtrelenmiş ligler export edildi: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Export hatası: {e}")
            return False
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Filtreleme istatistiklerini döndürür
        
        Returns:
            Dict: İstatistikler
        """
        try:
            # Tüm ligleri parse et
            all_leagues = []
            
            with open(self.leagues_file_path, 'r', encoding='utf-8') as file:
                content = file.read()
            
            lines = content.strip().split('\n')
            
            for line in lines:
                if line.strip():
                    match = re.match(r'ID:\s*(\d+),\s*Lig:\s*([^,]+),\s*Ülke:\s*(.+)', line.strip())
                    if match:
                        league_id = int(match.group(1))
                        league_name = match.group(2).strip()
                        country = match.group(3).strip()
                        
                        all_leagues.append({
                            'league_id': league_id,
                            'league_name': league_name,
                            'country': country
                        })
            
            all_leagues_df = pd.DataFrame(all_leagues)
            filtered_leagues_df = self.parse_and_filter_leagues()
            
            # Öncelik grupları
            priority_groups = self.get_filtered_leagues_by_priority()
            
            stats = {
                'total_leagues': len(all_leagues_df),
                'filtered_leagues': len(filtered_leagues_df),
                'filter_ratio': len(filtered_leagues_df) / len(all_leagues_df) * 100,
                'priority_1_count': len(priority_groups.get(1, [])),
                'priority_2_count': len(priority_groups.get(2, [])),
                'priority_3_count': len(priority_groups.get(3, [])),
                'countries_total': all_leagues_df['country'].nunique(),
                'countries_filtered': filtered_leagues_df['country'].nunique() if not filtered_leagues_df.empty else 0
            }
            
            return stats
            
        except Exception as e:
            logger.error(f"İstatistik hesaplama hatası: {e}")
            return {}


def test_high_quality_filter():
    """
    Yüksek kaliteli lig filtresini test eder
    """
    try:
        print("=== Yüksek Kaliteli Lig Filtresi Testi ===\n")
        
        # Filtreyi oluştur
        filter_system = HighQualityLeaguesFilter('/home/ubuntu/upload/all_leagues.txt')
        
        # İstatistikleri al
        print("1. Filtreleme istatistikleri:")
        stats = filter_system.get_statistics()
        
        print(f"   - Toplam lig sayısı: {stats['total_leagues']}")
        print(f"   - Filtrelenmiş lig sayısı: {stats['filtered_leagues']}")
        print(f"   - Filtreleme oranı: {stats['filter_ratio']:.1f}%")
        print(f"   - Öncelik 1 (En yüksek): {stats['priority_1_count']} lig")
        print(f"   - Öncelik 2 (Yüksek): {stats['priority_2_count']} lig")
        print(f"   - Öncelik 3 (Normal): {stats['priority_3_count']} lig")
        print(f"   - Toplam ülke: {stats['countries_total']}")
        print(f"   - Filtrelenmiş ülke: {stats['countries_filtered']}")
        
        # Öncelik gruplarını göster
        print("\n2. Öncelik grupları:")
        priority_groups = filter_system.get_filtered_leagues_by_priority()
        
        for priority, leagues in priority_groups.items():
            priority_names = {1: "En Yüksek", 2: "Yüksek", 3: "Normal"}
            print(f"\n   {priority_names[priority]} Öncelik ({len(leagues)} lig):")
            
            for league in leagues[:10]:  # İlk 10'unu göster
                print(f"     - {league['league_name']} ({league['country']}) - Skor: {league.get('quality_score', 'N/A')}")
            
            if len(leagues) > 10:
                print(f"     ... ve {len(leagues) - 10} lig daha")
        
        # Export et
        print("\n3. Filtrelenmiş ligleri export ediliyor...")
        if filter_system.export_filtered_leagues('/home/ubuntu/football_prediction_system/high_quality_leagues.csv'):
            print("✅ Export başarılı")
        else:
            print("❌ Export başarısız")
        
        print("\n✅ Yüksek kaliteli lig filtresi testi başarılı!")
        
    except Exception as e:
        print(f"❌ Test hatası: {e}")


if __name__ == "__main__":
    test_high_quality_filter()

