import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { AlertCircle, TrendingUp, Target, Brain, BarChart3, Search, Calendar, Trophy } from 'lucide-react'
import './App.css'

function App() {
  const [selectedMatch, setSelectedMatch] = useState(null)
  const [prediction, setPrediction] = useState(null)
  const [loading, setLoading] = useState(false)
  const [matches, setMatches] = useState([])
  const [searchResults, setSearchResults] = useState([])

  // Örnek maç verileri
  const sampleMatches = [
    {
      id: 1,
      home_team: { id: 33, name: 'Manchester United', logo: '🔴' },
      away_team: { id: 34, name: 'Newcastle United', logo: '⚫' },
      league: 'Premier League',
      date: '2025-09-15T15:00:00Z',
      status: 'NS'
    },
    {
      id: 2,
      home_team: { id: 40, name: 'Liverpool', logo: '🔴' },
      away_team: { id: 50, name: 'Manchester City', logo: '🔵' },
      league: 'Premier League',
      date: '2025-09-15T17:30:00Z',
      status: 'NS'
    },
    {
      id: 3,
      home_team: { id: 42, name: 'Arsenal', logo: '🔴' },
      away_team: { id: 49, name: 'Chelsea', logo: '🔵' },
      league: 'Premier League',
      date: '2025-09-16T14:00:00Z',
      status: 'NS'
    }
  ]

  useEffect(() => {
    setMatches(sampleMatches)
  }, [])

  const handlePredictMatch = async (match) => {
    setLoading(true)
    setSelectedMatch(match)
    
    try {
      // API çağrısı simülasyonu
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Örnek tahmin sonucu
      const mockPrediction = {
        match_info: {
          home_team: match.home_team,
          away_team: match.away_team,
          league: match.league
        },
        predictions: {
          ensemble: {
            home_win_probability: 0.472,
            draw_probability: 0.264,
            away_win_probability: 0.264,
            over_2_5_probability: 0.560,
            both_teams_score_probability: 0.650,
            expected_home_goals: 1.8,
            expected_away_goals: 1.2,
            confidence_score: 0.869
          }
        },
        betting_options: {
          match_result: {
            home_win: 0.472,
            draw: 0.264,
            away_win: 0.264
          },
          over_under_goals: {
            over_2_5: 0.560,
            under_2_5: 0.440
          },
          both_teams_score: {
            yes: 0.650,
            no: 0.350
          }
        },
        ai_analysis: {
          interpretation: {
            match_prediction: 'ev sahibi galip',
            confidence_level: 'yüksek',
            explanation: 'Manchester United ev sahibi avantajı ve son form durumu ile favori görünüyor. Newcastle\'ın deplasman performansı zayıf.',
            key_factors: [
              'Ev sahibi avantajı',
              'Son 5 maçtaki form farkı',
              'Head-to-head üstünlük'
            ]
          }
        }
      }
      
      setPrediction(mockPrediction)
    } catch (error) {
      console.error('Tahmin hatası:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatProbability = (prob) => {
    return `${(prob * 100).toFixed(1)}%`
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('tr-TR', {
      day: 'numeric',
      month: 'long',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-green-600 to-blue-600 p-3 rounded-xl">
                <Trophy className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">
                  Futbol Analiz Sistemi
                </h1>
                <p className="text-gray-600">AI destekli maç tahmin platformu</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <Brain className="w-4 h-4 mr-1" />
                AI Aktif
              </Badge>
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                524 Lig
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="matches" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 lg:w-[400px]">
            <TabsTrigger value="matches" className="flex items-center space-x-2">
              <Calendar className="w-4 h-4" />
              <span>Maçlar</span>
            </TabsTrigger>
            <TabsTrigger value="search" className="flex items-center space-x-2">
              <Search className="w-4 h-4" />
              <span>Arama</span>
            </TabsTrigger>
            <TabsTrigger value="analysis" className="flex items-center space-x-2">
              <BarChart3 className="w-4 h-4" />
              <span>Analiz</span>
            </TabsTrigger>
          </TabsList>

          {/* Maçlar Sekmesi */}
          <TabsContent value="matches" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Maç Listesi */}
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Calendar className="w-5 h-5" />
                      <span>Yaklaşan Maçlar</span>
                    </CardTitle>
                    <CardDescription>
                      Tahmin yapabileceğiniz güncel maçlar
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {matches.map((match) => (
                      <div
                        key={match.id}
                        className="p-4 border rounded-lg hover:shadow-md transition-shadow cursor-pointer bg-white"
                        onClick={() => handlePredictMatch(match)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div className="text-center">
                              <div className="text-2xl">{match.home_team.logo}</div>
                              <div className="text-sm font-medium">{match.home_team.name}</div>
                            </div>
                            <div className="text-gray-400 font-bold">VS</div>
                            <div className="text-center">
                              <div className="text-2xl">{match.away_team.logo}</div>
                              <div className="text-sm font-medium">{match.away_team.name}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm text-gray-600">{match.league}</div>
                            <div className="text-xs text-gray-500">{formatDate(match.date)}</div>
                            <Button size="sm" className="mt-2">
                              <Target className="w-4 h-4 mr-1" />
                              Tahmin Et
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>

              {/* Tahmin Sonuçları */}
              <div className="space-y-4">
                {loading && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Tahmin Hesaplanıyor...</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <Progress value={33} className="w-full" />
                        <p className="text-sm text-gray-600">
                          AI modelleri analiz ediyor...
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {prediction && !loading && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Brain className="w-5 h-5" />
                        <span>Tahmin Sonuçları</span>
                      </CardTitle>
                      <CardDescription>
                        {prediction.match_info.home_team.name} vs {prediction.match_info.away_team.name}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Ana Tahmin */}
                      <div className="space-y-3">
                        <h4 className="font-semibold">Maç Sonucu</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span>Ev Sahibi Galip</span>
                            <div className="flex items-center space-x-2">
                              <Progress 
                                value={prediction.predictions.ensemble.home_win_probability * 100} 
                                className="w-20" 
                              />
                              <span className="text-sm font-medium">
                                {formatProbability(prediction.predictions.ensemble.home_win_probability)}
                              </span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span>Beraberlik</span>
                            <div className="flex items-center space-x-2">
                              <Progress 
                                value={prediction.predictions.ensemble.draw_probability * 100} 
                                className="w-20" 
                              />
                              <span className="text-sm font-medium">
                                {formatProbability(prediction.predictions.ensemble.draw_probability)}
                              </span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span>Deplasman Galip</span>
                            <div className="flex items-center space-x-2">
                              <Progress 
                                value={prediction.predictions.ensemble.away_win_probability * 100} 
                                className="w-20" 
                              />
                              <span className="text-sm font-medium">
                                {formatProbability(prediction.predictions.ensemble.away_win_probability)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Diğer Bahisler */}
                      <div className="space-y-3">
                        <h4 className="font-semibold">Diğer Bahis Seçenekleri</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="p-3 bg-gray-50 rounded-lg">
                            <div className="text-sm text-gray-600">Over 2.5 Gol</div>
                            <div className="text-lg font-semibold">
                              {formatProbability(prediction.predictions.ensemble.over_2_5_probability)}
                            </div>
                          </div>
                          <div className="p-3 bg-gray-50 rounded-lg">
                            <div className="text-sm text-gray-600">Her İki Takım Gol</div>
                            <div className="text-lg font-semibold">
                              {formatProbability(prediction.predictions.ensemble.both_teams_score_probability)}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* AI Yorumlama */}
                      {prediction.ai_analysis?.interpretation && (
                        <div className="space-y-3">
                          <h4 className="font-semibold flex items-center space-x-2">
                            <Brain className="w-4 h-4" />
                            <span>AI Analizi</span>
                          </h4>
                          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                            <p className="text-sm text-blue-800 mb-2">
                              {prediction.ai_analysis.interpretation.explanation}
                            </p>
                            <div className="flex flex-wrap gap-2">
                              {prediction.ai_analysis.interpretation.key_factors?.map((factor, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {factor}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Güven Skoru */}
                      <div className="space-y-3">
                        <h4 className="font-semibold">Güven Skoru</h4>
                        <div className="flex items-center space-x-3">
                          <Progress 
                            value={prediction.predictions.ensemble.confidence_score * 100} 
                            className="flex-1" 
                          />
                          <span className="text-lg font-semibold">
                            {formatProbability(prediction.predictions.ensemble.confidence_score)}
                          </span>
                        </div>
                        <p className="text-xs text-gray-600">
                          Yüksek güven skoru daha güvenilir tahmin anlamına gelir
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Arama Sekmesi */}
          <TabsContent value="search" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Maç Arama</CardTitle>
                <CardDescription>
                  524 kaliteli ligden maç arayın
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="league">Lig</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Lig seçin" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="39">Premier League</SelectItem>
                        <SelectItem value="140">La Liga</SelectItem>
                        <SelectItem value="78">Bundesliga</SelectItem>
                        <SelectItem value="135">Serie A</SelectItem>
                        <SelectItem value="61">Ligue 1</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="date">Tarih</Label>
                    <Input type="date" />
                  </div>
                  <div>
                    <Label htmlFor="team">Takım</Label>
                    <Input placeholder="Takım adı..." />
                  </div>
                </div>
                <Button className="w-full">
                  <Search className="w-4 h-4 mr-2" />
                  Maç Ara
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analiz Sekmesi */}
          <TabsContent value="analysis" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5" />
                    <span>Model Performansı</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>XGBoost</span>
                      <span className="font-semibold">85.0%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>LightGBM</span>
                      <span className="font-semibold">86.0%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>CatBoost</span>
                      <span className="font-semibold">87.0%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Sistem Durumu</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span>API Bağlantısı</span>
                      <Badge className="bg-green-100 text-green-800">Aktif</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>AI Modelleri</span>
                      <Badge className="bg-green-100 text-green-800">3/3</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Veritabanı</span>
                      <Badge className="bg-green-100 text-green-800">Bağlı</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>İstatistikler</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Toplam Lig</span>
                      <span className="font-semibold">524</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Günlük Tahmin</span>
                      <span className="font-semibold">150+</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Başarı Oranı</span>
                      <span className="font-semibold">78.5%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App

