"""
Veri Entegrasyon Modülü
Bu modül, API-Football'dan çekilen verileri veritabanına entegre eder.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import logging
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from database_models import DatabaseManager, League, Team, Fixture, FixtureStatistics, TeamStatistics, Player, PlayerStatistics, FeatureEngineering
from data_collector import FootballDataCollector
from all_leagues_parser import AllLeaguesParser

# Logging konfigürasyonu
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataIntegration:
    """
    Veri entegrasyon sınıfı
    """
    
    def __init__(self, api_key: str, database_url: str):
        """
        Veri entegrasyonu başlatır
        
        Args:
            api_key (str): API-Football anahtarı
            database_url (str): Veritabanı bağlantı URL'i
        """
        self.data_collector = FootballDataCollector(api_key)
        self.db_manager = DatabaseManager(database_url)
        self.leagues_parser = AllLeaguesParser('/home/ubuntu/upload/all_leagues.txt')
        
        # Ligleri parse et
        self.leagues_df = self.leagues_parser.parse_leagues_file()
        self.priority_leagues = self.leagues_parser.get_priority_leagues()
        
    def sync_leagues(self, season: int = 2025) -> bool:
        """
        Ligleri veritabanına senkronize eder
        
        Args:
            season (int): Sezon
            
        Returns:
            bool: Başarı durumu
        """
        try:
            session = self.db_manager.get_session()
            
            synced_count = 0
            for _, league_data in self.leagues_df.iterrows():
                try:
                    # Mevcut ligi kontrol et
                    existing_league = session.query(League).filter(
                        and_(League.league_id == league_data['league_id'], League.season == season)
                    ).first()
                    
                    if not existing_league:
                        # Yeni lig oluştur
                        new_league = League(
                            league_id=league_data['league_id'],
                            name=league_data['league_name'],
                            country=league_data['country'],
                            season=season
                        )
                        session.add(new_league)
                        synced_count += 1
                    
                except Exception as e:
                    logger.warning(f"Lig senkronizasyon hatası (ID: {league_data['league_id']}): {e}")
                    continue
            
            session.commit()
            logger.info(f"{synced_count} lig veritabanına senkronize edildi")
            return True
            
        except Exception as e:
            session.rollback()
            logger.error(f"Lig senkronizasyon hatası: {e}")
            return False
        finally:
            session.close()
    
    def sync_teams(self, league_ids: Optional[List[int]] = None, season: int = 2025) -> bool:
        """
        Takımları veritabanına senkronize eder
        
        Args:
            league_ids (List[int]): Lig ID'leri (None ise öncelikli ligler)
            season (int): Sezon
            
        Returns:
            bool: Başarı durumu
        """
        try:
            if not league_ids:
                league_ids = [league['league_id'] for league in self.priority_leagues[:10]]
            
            session = self.db_manager.get_session()
            synced_count = 0
            
            for league_id in league_ids:
                try:
                    # API'den takımları çek
                    teams_df = self.data_collector.collect_league_teams(league_id, season)
                    
                    if teams_df.empty:
                        continue
                    
                    for _, team_data in teams_df.iterrows():
                        # Mevcut takımı kontrol et
                        existing_team = session.query(Team).filter(
                            Team.team_id == team_data['team_id']
                        ).first()
                        
                        if not existing_team:
                            # Yeni takım oluştur
                            new_team = Team(
                                team_id=team_data['team_id'],
                                name=team_data['team_name'],
                                code=team_data.get('team_code'),
                                country=team_data.get('country'),
                                founded=team_data.get('founded'),
                                venue_id=team_data.get('venue_id'),
                                venue_name=team_data.get('venue_name'),
                                venue_capacity=team_data.get('venue_capacity'),
                                league_id=league_id
                            )
                            session.add(new_team)
                            synced_count += 1
                        else:
                            # Mevcut takımı güncelle
                            existing_team.name = team_data['team_name']
                            existing_team.code = team_data.get('team_code')
                            existing_team.country = team_data.get('country')
                            existing_team.updated_at = datetime.utcnow()
                    
                except Exception as e:
                    logger.warning(f"Takım senkronizasyon hatası (Lig: {league_id}): {e}")
                    continue
            
            session.commit()
            logger.info(f"{synced_count} takım veritabanına senkronize edildi")
            return True
            
        except Exception as e:
            session.rollback()
            logger.error(f"Takım senkronizasyon hatası: {e}")
            return False
        finally:
            session.close()
    
    def sync_fixtures(self, league_ids: Optional[List[int]] = None, season: int = 2025, 
                     date_from: Optional[str] = None, date_to: Optional[str] = None) -> bool:
        """
        Maçları veritabanına senkronize eder
        
        Args:
            league_ids (List[int]): Lig ID'leri
            season (int): Sezon
            date_from (str): Başlangıç tarihi
            date_to (str): Bitiş tarihi
            
        Returns:
            bool: Başarı durumu
        """
        try:
            if not league_ids:
                league_ids = [league['league_id'] for league in self.priority_leagues[:5]]
            
            session = self.db_manager.get_session()
            synced_count = 0
            
            for league_id in league_ids:
                try:
                    # API'den maçları çek
                    fixtures_df = self.data_collector.collect_fixtures(
                        league_id=league_id,
                        season=season,
                        date_from=date_from,
                        date_to=date_to
                    )
                    
                    if fixtures_df.empty:
                        continue
                    
                    for _, fixture_data in fixtures_df.iterrows():
                        # Mevcut maçı kontrol et
                        existing_fixture = session.query(Fixture).filter(
                            Fixture.fixture_id == fixture_data['fixture_id']
                        ).first()
                        
                        if not existing_fixture:
                            # Yeni maç oluştur
                            new_fixture = Fixture(
                                fixture_id=fixture_data['fixture_id'],
                                date=pd.to_datetime(fixture_data['date']),
                                status=fixture_data['status'],
                                round=fixture_data.get('round'),
                                home_team_id=fixture_data['home_team_id'],
                                away_team_id=fixture_data['away_team_id'],
                                home_goals=fixture_data.get('home_goals'),
                                away_goals=fixture_data.get('away_goals'),
                                league_id=league_id,
                                season=season
                            )
                            session.add(new_fixture)
                            synced_count += 1
                        else:
                            # Mevcut maçı güncelle
                            existing_fixture.status = fixture_data['status']
                            existing_fixture.home_goals = fixture_data.get('home_goals')
                            existing_fixture.away_goals = fixture_data.get('away_goals')
                            existing_fixture.updated_at = datetime.utcnow()
                    
                except Exception as e:
                    logger.warning(f"Maç senkronizasyon hatası (Lig: {league_id}): {e}")
                    continue
            
            session.commit()
            logger.info(f"{synced_count} maç veritabanına senkronize edildi")
            return True
            
        except Exception as e:
            session.rollback()
            logger.error(f"Maç senkronizasyon hatası: {e}")
            return False
        finally:
            session.close()
    
    def sync_team_statistics(self, league_ids: Optional[List[int]] = None, season: int = 2025) -> bool:
        """
        Takım istatistiklerini veritabanına senkronize eder
        
        Args:
            league_ids (List[int]): Lig ID'leri
            season (int): Sezon
            
        Returns:
            bool: Başarı durumu
        """
        try:
            if not league_ids:
                league_ids = [league['league_id'] for league in self.priority_leagues[:5]]
            
            session = self.db_manager.get_session()
            synced_count = 0
            
            for league_id in league_ids:
                try:
                    # Ligin takımlarını al
                    teams = session.query(Team).filter(Team.league_id == league_id).all()
                    
                    for team in teams:
                        # API'den takım istatistiklerini çek
                        stats = self.data_collector.collect_team_statistics(
                            team_id=team.team_id,
                            league_id=league_id,
                            season=season
                        )
                        
                        if not stats:
                            continue
                        
                        # Mevcut istatistikleri kontrol et
                        existing_stats = session.query(TeamStatistics).filter(
                            and_(
                                TeamStatistics.team_id == team.team_id,
                                TeamStatistics.league_id == league_id,
                                TeamStatistics.season == season
                            )
                        ).first()
                        
                        if not existing_stats:
                            # Yeni istatistik oluştur
                            new_stats = TeamStatistics(
                                team_id=team.team_id,
                                league_id=league_id,
                                season=season,
                                matches_played=stats.get('matches_played', 0),
                                wins=stats.get('wins', 0),
                                draws=stats.get('draws', 0),
                                losses=stats.get('losses', 0),
                                goals_for=stats.get('goals_for', 0),
                                goals_against=stats.get('goals_against', 0),
                                clean_sheets=stats.get('clean_sheets', 0),
                                failed_to_score=stats.get('failed_to_score', 0)
                            )
                            session.add(new_stats)
                            synced_count += 1
                        else:
                            # Mevcut istatistikleri güncelle
                            existing_stats.matches_played = stats.get('matches_played', 0)
                            existing_stats.wins = stats.get('wins', 0)
                            existing_stats.draws = stats.get('draws', 0)
                            existing_stats.losses = stats.get('losses', 0)
                            existing_stats.goals_for = stats.get('goals_for', 0)
                            existing_stats.goals_against = stats.get('goals_against', 0)
                            existing_stats.clean_sheets = stats.get('clean_sheets', 0)
                            existing_stats.failed_to_score = stats.get('failed_to_score', 0)
                            existing_stats.updated_at = datetime.utcnow()
                    
                except Exception as e:
                    logger.warning(f"Takım istatistik senkronizasyon hatası (Lig: {league_id}): {e}")
                    continue
            
            session.commit()
            logger.info(f"{synced_count} takım istatistiği veritabanına senkronize edildi")
            return True
            
        except Exception as e:
            session.rollback()
            logger.error(f"Takım istatistik senkronizasyon hatası: {e}")
            return False
        finally:
            session.close()
    
    def calculate_feature_engineering(self, fixture_id: int) -> bool:
        """
        Belirli bir maç için özellik mühendisliği verilerini hesaplar
        
        Args:
            fixture_id (int): Maç ID'si
            
        Returns:
            bool: Başarı durumu
        """
        try:
            session = self.db_manager.get_session()
            
            # Maç bilgilerini al
            fixture = session.query(Fixture).filter(Fixture.fixture_id == fixture_id).first()
            if not fixture:
                logger.warning(f"Maç bulunamadı: {fixture_id}")
                return False
            
            # Her iki takım için özellik mühendisliği hesapla
            for team_id in [fixture.home_team_id, fixture.away_team_id]:
                # Son 5 maçın formunu hesapla
                recent_fixtures = session.query(Fixture).filter(
                    and_(
                        or_(Fixture.home_team_id == team_id, Fixture.away_team_id == team_id),
                        Fixture.date < fixture.date,
                        Fixture.status == 'FT'
                    )
                ).order_by(Fixture.date.desc()).limit(5).all()
                
                form_points = 0
                form_wins = 0
                form_draws = 0
                form_losses = 0
                goals_for = 0
                goals_against = 0
                
                for recent_fixture in recent_fixtures:
                    if recent_fixture.home_team_id == team_id:
                        # Ev sahibi
                        home_goals = recent_fixture.home_goals or 0
                        away_goals = recent_fixture.away_goals or 0
                        goals_for += home_goals
                        goals_against += away_goals
                        
                        if home_goals > away_goals:
                            form_wins += 1
                            form_points += 3
                        elif home_goals == away_goals:
                            form_draws += 1
                            form_points += 1
                        else:
                            form_losses += 1
                    else:
                        # Deplasman
                        home_goals = recent_fixture.home_goals or 0
                        away_goals = recent_fixture.away_goals or 0
                        goals_for += away_goals
                        goals_against += home_goals
                        
                        if away_goals > home_goals:
                            form_wins += 1
                            form_points += 3
                        elif away_goals == home_goals:
                            form_draws += 1
                            form_points += 1
                        else:
                            form_losses += 1
                
                # Ev sahibi avantajı hesapla
                home_advantage = 1.0 if team_id == fixture.home_team_id else 0.0
                
                # Özellik mühendisliği verisini oluştur
                feature_data = FeatureEngineering(
                    fixture_id=fixture_id,
                    team_id=team_id,
                    form_last_5_points=form_points,
                    form_last_5_wins=form_wins,
                    form_last_5_draws=form_draws,
                    form_last_5_losses=form_losses,
                    goals_scored_avg_5=goals_for / max(len(recent_fixtures), 1),
                    goals_conceded_avg_5=goals_against / max(len(recent_fixtures), 1),
                    home_advantage_factor=home_advantage,
                    elo_rating=1500.0  # Varsayılan Elo rating
                )
                
                session.add(feature_data)
            
            session.commit()
            logger.info(f"Özellik mühendisliği hesaplandı: {fixture_id}")
            return True
            
        except Exception as e:
            session.rollback()
            logger.error(f"Özellik mühendisliği hatası: {e}")
            return False
        finally:
            session.close()
    
    def full_sync(self, season: int = 2025) -> bool:
        """
        Tam senkronizasyon yapar
        
        Args:
            season (int): Sezon
            
        Returns:
            bool: Başarı durumu
        """
        try:
            logger.info("Tam senkronizasyon başlatılıyor...")
            
            # 1. Ligleri senkronize et
            logger.info("1. Ligler senkronize ediliyor...")
            if not self.sync_leagues(season):
                logger.error("Lig senkronizasyonu başarısız")
                return False
            
            # 2. Takımları senkronize et
            logger.info("2. Takımlar senkronize ediliyor...")
            if not self.sync_teams(season=season):
                logger.error("Takım senkronizasyonu başarısız")
                return False
            
            # 3. Maçları senkronize et
            logger.info("3. Maçlar senkronize ediliyor...")
            if not self.sync_fixtures(season=season):
                logger.error("Maç senkronizasyonu başarısız")
                return False
            
            # 4. Takım istatistiklerini senkronize et
            logger.info("4. Takım istatistikleri senkronize ediliyor...")
            if not self.sync_team_statistics(season=season):
                logger.error("Takım istatistik senkronizasyonu başarısız")
                return False
            
            logger.info("✅ Tam senkronizasyon başarıyla tamamlandı")
            return True
            
        except Exception as e:
            logger.error(f"Tam senkronizasyon hatası: {e}")
            return False
    
    def get_database_stats(self) -> Dict[str, int]:
        """
        Veritabanı istatistiklerini döndürür
        
        Returns:
            Dict: Veritabanı istatistikleri
        """
        try:
            session = self.db_manager.get_session()
            
            stats = {
                'leagues': session.query(League).count(),
                'teams': session.query(Team).count(),
                'fixtures': session.query(Fixture).count(),
                'team_statistics': session.query(TeamStatistics).count(),
                'feature_engineering': session.query(FeatureEngineering).count()
            }
            
            return stats
            
        except Exception as e:
            logger.error(f"Veritabanı istatistik hatası: {e}")
            return {}
        finally:
            session.close()


def test_data_integration():
    """
    Veri entegrasyonunu test eder
    """
    api_key = "6e8bb5327emsh6512ba4710242aap152911jsnc708554057f0"
    database_url = "postgresql://football_user:football123@localhost/football_prediction_db"
    
    try:
        print("=== Veri Entegrasyon Testi ===\n")
        
        # Veri entegrasyonu oluştur
        data_integration = DataIntegration(api_key, database_url)
        
        # Veritabanı bağlantısını test et
        print("1. Veritabanı bağlantısı test ediliyor...")
        if data_integration.db_manager.test_connection():
            print("✅ Veritabanı bağlantısı başarılı")
        else:
            print("❌ Veritabanı bağlantısı başarısız")
            return
        
        # Başlangıç istatistikleri
        print("\n2. Başlangıç veritabanı durumu:")
        initial_stats = data_integration.get_database_stats()
        for key, value in initial_stats.items():
            print(f"   - {key}: {value}")
        
        # Ligleri senkronize et (sadece öncelikli ligler)
        print("\n3. Öncelikli ligler senkronize ediliyor...")
        priority_league_ids = [league['league_id'] for league in data_integration.priority_leagues[:3]]
        
        # Manuel lig ekleme
        session = data_integration.db_manager.get_session()
        for league_data in data_integration.priority_leagues[:3]:
            existing_league = session.query(League).filter(
                and_(League.league_id == league_data['league_id'], League.season == 2025)
            ).first()
            
            if not existing_league:
                new_league = League(
                    league_id=league_data['league_id'],
                    name=league_data['name'],
                    country=league_data['country'],
                    season=2025
                )
                session.add(new_league)
        
        session.commit()
        session.close()
        print("✅ Öncelikli ligler eklendi")
        
        # Takımları senkronize et
        print("\n4. Takımlar senkronize ediliyor...")
        if data_integration.sync_teams(league_ids=priority_league_ids[:2], season=2025):
            print("✅ Takımlar senkronize edildi")
        else:
            print("❌ Takım senkronizasyonu başarısız")
        
        # Maçları senkronize et
        print("\n5. Maçlar senkronize ediliyor...")
        if data_integration.sync_fixtures(league_ids=priority_league_ids[:1], season=2025):
            print("✅ Maçlar senkronize edildi")
        else:
            print("❌ Maç senkronizasyonu başarısız")
        
        # Son durum istatistikleri
        print("\n6. Son veritabanı durumu:")
        final_stats = data_integration.get_database_stats()
        for key, value in final_stats.items():
            change = value - initial_stats.get(key, 0)
            print(f"   - {key}: {value} (+{change})")
        
        print("\n✅ Veri entegrasyon testi başarılı!")
        
    except Exception as e:
        print(f"❌ Veri entegrasyon testi başarısız: {e}")


if __name__ == "__main__":
    test_data_integration()

