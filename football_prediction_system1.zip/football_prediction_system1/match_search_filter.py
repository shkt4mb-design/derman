"""
Detaylı Maç Arama ve Takvim Filtresi Modülü
Bu modül, kullanıcıların maçları detaylı şekilde arayabilmesi ve filtreleyebilmesi için geliştirilmiştir.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
from typing import Dict, List, Optional, Any, Tuple, Union
import logging
from api_football_client import APIFootballClient
from data_collector import FootballDataCollector
from all_leagues_parser import AllLeaguesParser

# Logging konfigürasyonu
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MatchSearchFilter:
    """
    Detaylı maç arama ve filtreleme sistemi
    """
    
    def __init__(self, api_key: str):
        """
        Arama ve filtreleme sistemini başlatır
        
        Args:
            api_key (str): API-Football anahtarı
        """
        self.api_client = APIFootballClient(api_key)
        self.data_collector = FootballDataCollector(api_key)
        self.leagues_parser = AllLeaguesParser('/home/ubuntu/upload/all_leagues.txt')
        
        # Ligleri parse et
        self.leagues_df = self.leagues_parser.parse_leagues_file()
        self.leagues_categories = self.leagues_parser.categorize_leagues(self.leagues_df)
        
        # Önbellek
        self.cache = {
            'fixtures': {},
            'teams': {},
            'search_results': {}
        }
        
        # Maç durumları
        self.match_statuses = {
            'TBD': 'Tarih Belirlenmedi',
            'NS': 'Başlamadı',
            '1H': '1. Yarı',
            'HT': 'Devre Arası',
            '2H': '2. Yarı',
            'ET': 'Uzatma',
            'BT': 'Penaltı Atışları',
            'P': 'Penaltı',
            'FT': 'Bitti',
            'AET': 'Uzatmada Bitti',
            'PEN': 'Penaltıda Bitti',
            'PST': 'Ertelendi',
            'CANC': 'İptal Edildi',
            'ABD': 'Yarıda Kesildi',
            'AWD': 'Hükmen',
            'WO': 'Walkover',
            'LIVE': 'Canlı'
        }
    
    def search_matches_advanced(self, 
                               league_ids: Optional[List[int]] = None,
                               team_ids: Optional[List[int]] = None,
                               team_names: Optional[List[str]] = None,
                               date_from: Optional[str] = None,
                               date_to: Optional[str] = None,
                               status: Optional[str] = None,
                               season: Optional[int] = None,
                               round_filter: Optional[str] = None,
                               venue_type: Optional[str] = None,
                               country: Optional[str] = None,
                               league_category: Optional[str] = None,
                               limit: Optional[int] = None) -> pd.DataFrame:
        """
        Gelişmiş maç arama fonksiyonu
        
        Args:
            league_ids: Lig ID'leri listesi
            team_ids: Takım ID'leri listesi
            team_names: Takım isimleri listesi
            date_from: Başlangıç tarihi (YYYY-MM-DD)
            date_to: Bitiş tarihi (YYYY-MM-DD)
            status: Maç durumu
            season: Sezon
            round_filter: Hafta filtresi
            venue_type: Saha türü (home/away)
            country: Ülke filtresi
            league_category: Lig kategorisi
            limit: Sonuç limiti
            
        Returns:
            pd.DataFrame: Filtrelenmiş maçlar
        """
        try:
            all_matches = pd.DataFrame()
            
            # Lig kategorisine göre lig ID'lerini belirle
            if league_category and not league_ids:
                if league_category in self.leagues_categories:
                    league_ids = [league['league_id'] for league in self.leagues_categories[league_category]['leagues']]
                    logger.info(f"Kategori '{league_category}' için {len(league_ids)} lig seçildi")
            
            # Ülkeye göre lig ID'lerini belirle
            if country and not league_ids:
                country_leagues = self.leagues_parser.get_leagues_by_country(country)
                league_ids = [league['league_id'] for league in country_leagues]
                logger.info(f"Ülke '{country}' için {len(league_ids)} lig seçildi")
            
            # Takım isimlerinden ID'leri bul
            if team_names and not team_ids:
                team_ids = []
                for team_name in team_names:
                    teams = self.search_teams_by_name(team_name)
                    if teams:
                        team_ids.extend([team['team_id'] for team in teams])
            
            # Varsayılan değerler
            if not season:
                season = 2025
            
            if not league_ids:
                # Öncelikli ligleri kullan
                priority_leagues = self.leagues_parser.get_priority_leagues()
                league_ids = [league['league_id'] for league in priority_leagues[:10]]
            
            # Her lig için maçları çek
            for league_id in league_ids[:20]:  # Performans için ilk 20 lig
                try:
                    fixtures = self.data_collector.collect_fixtures(
                        league_id=league_id,
                        season=season,
                        date_from=date_from,
                        date_to=date_to
                    )
                    
                    if not fixtures.empty:
                        # Lig bilgisini ekle
                        league_info = self.leagues_df[self.leagues_df['league_id'] == league_id]
                        if not league_info.empty:
                            fixtures['league_name'] = league_info.iloc[0]['league_name']
                            fixtures['country'] = league_info.iloc[0]['country']
                        
                        all_matches = pd.concat([all_matches, fixtures], ignore_index=True)
                        
                except Exception as e:
                    logger.warning(f"Lig {league_id} için maçlar alınamadı: {e}")
                    continue
            
            if all_matches.empty:
                logger.warning("Hiç maç bulunamadı")
                return pd.DataFrame()
            
            # Filtreleme işlemleri
            filtered_matches = self._apply_filters(
                all_matches, 
                team_ids=team_ids,
                status=status,
                round_filter=round_filter,
                venue_type=venue_type
            )
            
            # Sıralama ve limit
            if not filtered_matches.empty:
                filtered_matches['date'] = pd.to_datetime(filtered_matches['date'])
                filtered_matches = filtered_matches.sort_values('date', ascending=True)
                
                if limit:
                    filtered_matches = filtered_matches.head(limit)
            
            logger.info(f"Toplam {len(filtered_matches)} maç bulundu")
            return filtered_matches
            
        except Exception as e:
            logger.error(f"Gelişmiş arama hatası: {e}")
            return pd.DataFrame()
    
    def _apply_filters(self, matches_df: pd.DataFrame, **filters) -> pd.DataFrame:
        """
        Maçlara filtreleri uygular
        
        Args:
            matches_df: Maç verileri
            **filters: Filtre parametreleri
            
        Returns:
            pd.DataFrame: Filtrelenmiş maçlar
        """
        filtered_df = matches_df.copy()
        
        # Takım ID filtresi
        if filters.get('team_ids'):
            team_ids = filters['team_ids']
            filtered_df = filtered_df[
                (filtered_df['home_team_id'].isin(team_ids)) |
                (filtered_df['away_team_id'].isin(team_ids))
            ]
        
        # Durum filtresi
        if filters.get('status'):
            filtered_df = filtered_df[filtered_df['status'] == filters['status']]
        
        # Hafta filtresi
        if filters.get('round_filter'):
            round_filter = filters['round_filter']
            filtered_df = filtered_df[filtered_df['round'].str.contains(round_filter, case=False, na=False)]
        
        # Saha türü filtresi
        if filters.get('venue_type') and filters.get('team_ids'):
            venue_type = filters['venue_type']
            team_ids = filters['team_ids']
            
            if venue_type == 'home':
                filtered_df = filtered_df[filtered_df['home_team_id'].isin(team_ids)]
            elif venue_type == 'away':
                filtered_df = filtered_df[filtered_df['away_team_id'].isin(team_ids)]
        
        return filtered_df
    
    def search_teams_by_name(self, team_name: str, limit: int = 10) -> List[Dict]:
        """
        Takım adına göre arama yapar
        
        Args:
            team_name: Takım adı
            limit: Sonuç limiti
            
        Returns:
            List[Dict]: Bulunan takımlar
        """
        try:
            # Öncelikli liglerde ara
            priority_leagues = self.leagues_parser.get_priority_leagues()
            found_teams = []
            
            for league in priority_leagues[:10]:
                try:
                    teams = self.data_collector.collect_league_teams(league['league_id'], 2025)
                    if not teams.empty:
                        # İsim benzerliği kontrolü
                        matching_teams = teams[
                            teams['team_name'].str.contains(team_name, case=False, na=False)
                        ]
                        
                        for _, team in matching_teams.iterrows():
                            found_teams.append({
                                'team_id': team['team_id'],
                                'team_name': team['team_name'],
                                'team_code': team['team_code'],
                                'country': team['country'],
                                'league_id': league['league_id'],
                                'league_name': league['name']
                            })
                            
                            if len(found_teams) >= limit:
                                break
                    
                    if len(found_teams) >= limit:
                        break
                        
                except Exception as e:
                    logger.warning(f"Takım arama hatası (lig {league['league_id']}): {e}")
                    continue
            
            return found_teams[:limit]
            
        except Exception as e:
            logger.error(f"Takım arama hatası: {e}")
            return []
    
    def get_calendar_view(self, 
                         date_from: str, 
                         date_to: str,
                         league_ids: Optional[List[int]] = None,
                         team_ids: Optional[List[int]] = None) -> Dict[str, List[Dict]]:
        """
        Takvim görünümü için maçları gruplar
        
        Args:
            date_from: Başlangıç tarihi
            date_to: Bitiş tarihi
            league_ids: Lig ID'leri
            team_ids: Takım ID'leri
            
        Returns:
            Dict: Tarihe göre gruplandırılmış maçlar
        """
        try:
            matches = self.search_matches_advanced(
                league_ids=league_ids,
                team_ids=team_ids,
                date_from=date_from,
                date_to=date_to
            )
            
            if matches.empty:
                return {}
            
            # Tarihe göre grupla
            matches['date_only'] = pd.to_datetime(matches['date']).dt.date
            calendar_data = {}
            
            for date_key, day_matches in matches.groupby('date_only'):
                date_str = date_key.strftime('%Y-%m-%d')
                calendar_data[date_str] = []
                
                for _, match in day_matches.iterrows():
                    match_info = {
                        'fixture_id': match['fixture_id'],
                        'time': pd.to_datetime(match['date']).strftime('%H:%M'),
                        'home_team': match['home_team_name'],
                        'away_team': match['away_team_name'],
                        'league': match.get('league_name', 'Bilinmeyen'),
                        'status': match['status'],
                        'status_text': self.match_statuses.get(match['status'], match['status']),
                        'home_goals': match.get('home_goals'),
                        'away_goals': match.get('away_goals'),
                        'round': match.get('round', '')
                    }
                    calendar_data[date_str].append(match_info)
            
            return calendar_data
            
        except Exception as e:
            logger.error(f"Takvim görünümü hatası: {e}")
            return {}
    
    def get_live_matches(self) -> pd.DataFrame:
        """
        Canlı maçları getirir
        
        Returns:
            pd.DataFrame: Canlı maçlar
        """
        try:
            return self.search_matches_advanced(
                status='LIVE',
                limit=50
            )
        except Exception as e:
            logger.error(f"Canlı maçlar alınamadı: {e}")
            return pd.DataFrame()
    
    def get_today_matches(self) -> pd.DataFrame:
        """
        Bugünün maçlarını getirir
        
        Returns:
            pd.DataFrame: Bugünün maçları
        """
        today = datetime.now().strftime('%Y-%m-%d')
        return self.search_matches_advanced(
            date_from=today,
            date_to=today,
            limit=100
        )
    
    def get_upcoming_matches(self, days: int = 7) -> pd.DataFrame:
        """
        Gelecek maçları getirir
        
        Args:
            days: Kaç gün sonrasına kadar
            
        Returns:
            pd.DataFrame: Gelecek maçlar
        """
        today = datetime.now()
        end_date = (today + timedelta(days=days)).strftime('%Y-%m-%d')
        today_str = today.strftime('%Y-%m-%d')
        
        return self.search_matches_advanced(
            date_from=today_str,
            date_to=end_date,
            status='NS',
            limit=200
        )
    
    def get_recent_matches(self, days: int = 7) -> pd.DataFrame:
        """
        Geçmiş maçları getirir
        
        Args:
            days: Kaç gün öncesinden
            
        Returns:
            pd.DataFrame: Geçmiş maçlar
        """
        today = datetime.now()
        start_date = (today - timedelta(days=days)).strftime('%Y-%m-%d')
        today_str = today.strftime('%Y-%m-%d')
        
        return self.search_matches_advanced(
            date_from=start_date,
            date_to=today_str,
            status='FT',
            limit=200
        )
    
    def get_match_suggestions(self, user_preferences: Dict) -> List[Dict]:
        """
        Kullanıcı tercihlerine göre maç önerileri
        
        Args:
            user_preferences: Kullanıcı tercihleri
            
        Returns:
            List[Dict]: Önerilen maçlar
        """
        try:
            suggestions = []
            
            # Favori takımların maçları
            if user_preferences.get('favorite_teams'):
                team_matches = self.search_matches_advanced(
                    team_ids=user_preferences['favorite_teams'],
                    date_from=datetime.now().strftime('%Y-%m-%d'),
                    limit=20
                )
                
                for _, match in team_matches.iterrows():
                    suggestions.append({
                        'type': 'favorite_team',
                        'reason': 'Favori takımınızın maçı',
                        'match': match.to_dict()
                    })
            
            # Favori liglerin önemli maçları
            if user_preferences.get('favorite_leagues'):
                league_matches = self.search_matches_advanced(
                    league_ids=user_preferences['favorite_leagues'],
                    date_from=datetime.now().strftime('%Y-%m-%d'),
                    limit=15
                )
                
                for _, match in league_matches.iterrows():
                    suggestions.append({
                        'type': 'favorite_league',
                        'reason': 'Favori liginizdeki maç',
                        'match': match.to_dict()
                    })
            
            # Canlı maçlar
            live_matches = self.get_live_matches()
            for _, match in live_matches.head(10).iterrows():
                suggestions.append({
                    'type': 'live',
                    'reason': 'Şu anda canlı',
                    'match': match.to_dict()
                })
            
            return suggestions[:30]
            
        except Exception as e:
            logger.error(f"Maç önerileri hatası: {e}")
            return []
    
    def export_search_results(self, matches_df: pd.DataFrame, filename: str) -> bool:
        """
        Arama sonuçlarını export eder
        
        Args:
            matches_df: Maç verileri
            filename: Dosya adı
            
        Returns:
            bool: Başarı durumu
        """
        try:
            if matches_df.empty:
                logger.warning("Export edilecek veri yok")
                return False
            
            # Kolon isimlerini Türkçeleştir
            export_df = matches_df.copy()
            column_mapping = {
                'fixture_id': 'Maç ID',
                'date': 'Tarih',
                'home_team_name': 'Ev Sahibi',
                'away_team_name': 'Deplasman',
                'home_goals': 'Ev Sahibi Gol',
                'away_goals': 'Deplasman Gol',
                'status': 'Durum',
                'league_name': 'Lig',
                'country': 'Ülke',
                'round': 'Hafta'
            }
            
            export_df = export_df.rename(columns=column_mapping)
            export_df.to_csv(filename, index=False, encoding='utf-8-sig')
            
            logger.info(f"Arama sonuçları export edildi: {filename}")
            return True
            
        except Exception as e:
            logger.error(f"Export hatası: {e}")
            return False


def test_match_search_filter():
    """
    Maç arama ve filtreleme sistemini test eder
    """
    api_key = "6e8bb5327emsh6512ba4710242aap152911jsnc708554057f0"
    search_filter = MatchSearchFilter(api_key)
    
    try:
        print("=== Maç Arama ve Filtreleme Sistemi Testi ===\n")
        
        # Bugünün maçları
        print("1. Bugünün maçları:")
        today_matches = search_filter.get_today_matches()
        print(f"Bulunan maç sayısı: {len(today_matches)}")
        if not today_matches.empty:
            print(today_matches[['home_team_name', 'away_team_name', 'league_name', 'status']].head())
        print()
        
        # Gelecek hafta maçları
        print("2. Gelecek 7 günün maçları:")
        upcoming_matches = search_filter.get_upcoming_matches(7)
        print(f"Bulunan maç sayısı: {len(upcoming_matches)}")
        if not upcoming_matches.empty:
            print(upcoming_matches[['date', 'home_team_name', 'away_team_name', 'league_name']].head())
        print()
        
        # Premier League maçları
        print("3. Premier League maçları:")
        pl_matches = search_filter.search_matches_advanced(
            league_ids=[39],  # Premier League
            limit=10
        )
        print(f"Bulunan maç sayısı: {len(pl_matches)}")
        if not pl_matches.empty:
            print(pl_matches[['date', 'home_team_name', 'away_team_name', 'status']].head())
        print()
        
        # Takım arama
        print("4. Takım arama (Manchester):")
        teams = search_filter.search_teams_by_name("Manchester", limit=5)
        for team in teams:
            print(f"- {team['team_name']} ({team['league_name']})")
        print()
        
        # Takvim görünümü
        print("5. Takvim görünümü (bugünden itibaren 3 gün):")
        today = datetime.now().strftime('%Y-%m-%d')
        end_date = (datetime.now() + timedelta(days=3)).strftime('%Y-%m-%d')
        calendar = search_filter.get_calendar_view(today, end_date, league_ids=[39, 140])
        
        for date_str, matches in list(calendar.items())[:3]:
            print(f"  {date_str}: {len(matches)} maç")
            for match in matches[:2]:
                print(f"    {match['time']} - {match['home_team']} vs {match['away_team']}")
        print()
        
        print("Maç arama ve filtreleme sistemi testi başarılı!")
        
    except Exception as e:
        print(f"Test hatası: {e}")


if __name__ == "__main__":
    test_match_search_filter()

