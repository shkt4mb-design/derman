"""
Futbol Tahmin API Endpoint'leri
Bu modül, maç tahminleri için RESTful API endpoint'lerini içerir.
"""

from flask import Blueprint, request, jsonify
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))

from ml_models import FootballMLModels
from gemini_integration import GeminiIntegration
from match_search_filter import MatchSearchFilter
from data_preparation import DataPreparation
import pandas as pd
import numpy as np
from datetime import datetime
import logging

# Logging konfigürasyonu
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

prediction_bp = Blueprint('prediction', __name__)

# Global değişkenler
ml_models = None
gemini_ai = None
search_filter = None
data_prep = None

def initialize_services():
    """
    Servisleri başlatır
    """
    global ml_models, gemini_ai, search_filter, data_prep
    
    try:
        # API anahtarları
        api_key = "6e8bb5327emsh6512ba4710242aap152911jsnc708554057f0"
        gemini_key = "AIzaSyBvgeHCoujarKyyHCAvmFTMyH8Inl6nf4w"
        database_url = "postgresql://football_user:football123@localhost/football_prediction_db"
        
        # Servisleri başlat
        ml_models = FootballMLModels()
        gemini_ai = GeminiIntegration(gemini_key)
        search_filter = MatchSearchFilter(api_key)
        data_prep = DataPreparation(api_key, database_url)
        
        logger.info("Servisler başarıyla başlatıldı")
        return True
        
    except Exception as e:
        logger.error(f"Servis başlatma hatası: {e}")
        return False

@prediction_bp.route('/health', methods=['GET'])
def health_check():
    """
    API sağlık kontrolü
    """
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })

@prediction_bp.route('/predict/match', methods=['POST'])
def predict_match():
    """
    Maç tahmini yapar
    
    Request Body:
    {
        "home_team_id": 33,
        "away_team_id": 34,
        "league_id": 39,
        "season": 2025
    }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'JSON verisi gerekli'}), 400
        
        # Gerekli alanları kontrol et
        required_fields = ['home_team_id', 'away_team_id', 'league_id', 'season']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'{field} alanı gerekli'}), 400
        
        home_team_id = data['home_team_id']
        away_team_id = data['away_team_id']
        league_id = data['league_id']
        season = data['season']
        
        # Takım bilgilerini al (örnek veri)
        home_team_stats = {
            'win_rate': 0.6,
            'goals_for_avg': 2.0,
            'goals_against_avg': 1.2,
            'form_points': 12
        }
        
        away_team_stats = {
            'win_rate': 0.4,
            'goals_for_avg': 1.5,
            'goals_against_avg': 1.8,
            'form_points': 8
        }
        
        # Monte Carlo simülasyonu
        if ml_models:
            mc_results = ml_models.monte_carlo_simulation(
                home_team_stats, away_team_stats, 10000
            )
        else:
            mc_results = {}
        
        # Gemini AI yorumlama
        interpretation = {}
        if gemini_ai and mc_results:
            interpretation = gemini_ai.interpret_prediction_results(
                f"Team {home_team_id}", f"Team {away_team_id}", mc_results
            )
        
        # 30 farklı bahis seçeneği
        betting_options = generate_betting_options(mc_results)
        
        response = {
            'match_info': {
                'home_team_id': home_team_id,
                'away_team_id': away_team_id,
                'league_id': league_id,
                'season': season
            },
            'predictions': mc_results,
            'betting_options': betting_options,
            'ai_interpretation': interpretation,
            'timestamp': datetime.now().isoformat(),
            'confidence_level': mc_results.get('simulation_count', 0) / 10000
        }
        
        return jsonify(response)
        
    except Exception as e:
        logger.error(f"Maç tahmini hatası: {e}")
        return jsonify({'error': 'Tahmin yapılırken hata oluştu'}), 500

@prediction_bp.route('/search/matches', methods=['GET'])
def search_matches():
    """
    Maç arama
    
    Query Parameters:
    - league_ids: Lig ID'leri (virgülle ayrılmış)
    - date_from: Başlangıç tarihi (YYYY-MM-DD)
    - date_to: Bitiş tarihi (YYYY-MM-DD)
    - status: Maç durumu
    - limit: Sonuç limiti
    """
    try:
        # Query parametrelerini al
        league_ids_str = request.args.get('league_ids', '')
        date_from = request.args.get('date_from')
        date_to = request.args.get('date_to')
        status = request.args.get('status')
        limit = request.args.get('limit', 50, type=int)
        
        # Lig ID'lerini parse et
        league_ids = []
        if league_ids_str:
            try:
                league_ids = [int(x.strip()) for x in league_ids_str.split(',')]
            except ValueError:
                return jsonify({'error': 'Geçersiz lig ID formatı'}), 400
        
        # Maç arama
        if search_filter:
            matches = search_filter.search_matches_advanced(
                league_ids=league_ids if league_ids else None,
                date_from=date_from,
                date_to=date_to,
                status=status,
                limit=limit
            )
            
            # DataFrame'i dict'e dönüştür
            if not matches.empty:
                matches_list = matches.to_dict('records')
                # Datetime objelerini string'e dönüştür
                for match in matches_list:
                    for key, value in match.items():
                        if isinstance(value, pd.Timestamp):
                            match[key] = value.isoformat()
                        elif pd.isna(value):
                            match[key] = None
            else:
                matches_list = []
        else:
            matches_list = []
        
        response = {
            'matches': matches_list,
            'count': len(matches_list),
            'filters': {
                'league_ids': league_ids,
                'date_from': date_from,
                'date_to': date_to,
                'status': status,
                'limit': limit
            },
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify(response)
        
    except Exception as e:
        logger.error(f"Maç arama hatası: {e}")
        return jsonify({'error': 'Maç arama sırasında hata oluştu'}), 500

@prediction_bp.route('/analyze/news', methods=['POST'])
def analyze_news():
    """
    Takım haberlerini analiz eder
    
    Request Body:
    {
        "team_name": "Manchester United",
        "news_text": "Haber metni..."
    }
    """
    try:
        data = request.get_json()
        
        if not data or 'team_name' not in data or 'news_text' not in data:
            return jsonify({'error': 'team_name ve news_text alanları gerekli'}), 400
        
        team_name = data['team_name']
        news_text = data['news_text']
        
        # Gemini AI ile haber analizi
        if gemini_ai:
            analysis = gemini_ai.analyze_team_news(team_name, news_text)
        else:
            analysis = {'error': 'AI servisi kullanılamıyor'}
        
        return jsonify(analysis)
        
    except Exception as e:
        logger.error(f"Haber analizi hatası: {e}")
        return jsonify({'error': 'Haber analizi sırasında hata oluştu'}), 500

@prediction_bp.route('/analyze/injury', methods=['POST'])
def analyze_injury():
    """
    Sakatlık raporlarını analiz eder
    
    Request Body:
    {
        "team_name": "Arsenal",
        "injury_text": "Sakatlık raporu..."
    }
    """
    try:
        data = request.get_json()
        
        if not data or 'team_name' not in data or 'injury_text' not in data:
            return jsonify({'error': 'team_name ve injury_text alanları gerekli'}), 400
        
        team_name = data['team_name']
        injury_text = data['injury_text']
        
        # Gemini AI ile sakatlık analizi
        if gemini_ai:
            analysis = gemini_ai.analyze_injury_report(team_name, injury_text)
        else:
            analysis = {'error': 'AI servisi kullanılamıyor'}
        
        return jsonify(analysis)
        
    except Exception as e:
        logger.error(f"Sakatlık analizi hatası: {e}")
        return jsonify({'error': 'Sakatlık analizi sırasında hata oluştu'}), 500

@prediction_bp.route('/leagues/quality', methods=['GET'])
def get_quality_leagues():
    """
    Kaliteli ligleri döndürür
    """
    try:
        # Kaliteli ligleri al (statik veri)
        quality_leagues = {
            'priority_1': [
                {'league_id': 39, 'name': 'Premier League', 'country': 'England'},
                {'league_id': 140, 'name': 'La Liga', 'country': 'Spain'},
                {'league_id': 135, 'name': 'Serie A', 'country': 'Italy'},
                {'league_id': 78, 'name': 'Bundesliga', 'country': 'Germany'},
                {'league_id': 61, 'name': 'Ligue 1', 'country': 'France'}
            ],
            'priority_2': [
                {'league_id': 88, 'name': 'Eredivisie', 'country': 'Netherlands'},
                {'league_id': 94, 'name': 'Primeira Liga', 'country': 'Portugal'},
                {'league_id': 203, 'name': 'Süper Lig', 'country': 'Turkey'}
            ]
        }
        
        return jsonify(quality_leagues)
        
    except Exception as e:
        logger.error(f"Kaliteli ligler hatası: {e}")
        return jsonify({'error': 'Kaliteli ligler alınamadı'}), 500

def generate_betting_options(mc_results):
    """
    30 farklı bahis seçeneği oluşturur
    
    Args:
        mc_results: Monte Carlo sonuçları
        
    Returns:
        Dict: Bahis seçenekleri
    """
    if not mc_results:
        return {}
    
    home_win = mc_results.get('home_win_probability', 0.33)
    draw = mc_results.get('draw_probability', 0.33)
    away_win = mc_results.get('away_win_probability', 0.33)
    over_2_5 = mc_results.get('over_2_5_probability', 0.5)
    btts = mc_results.get('both_teams_score_probability', 0.5)
    
    betting_options = {
        # Ana bahisler
        '1X2': {
            'home_win': home_win,
            'draw': draw,
            'away_win': away_win
        },
        
        # Çifte şans
        'double_chance': {
            '1X': home_win + draw,
            '12': home_win + away_win,
            'X2': draw + away_win
        },
        
        # Alt/Üst gol
        'over_under': {
            'over_0_5': mc_results.get('over_1_5_probability', 0.8),
            'over_1_5': mc_results.get('over_1_5_probability', 0.7),
            'over_2_5': over_2_5,
            'over_3_5': mc_results.get('over_3_5_probability', 0.3),
            'under_2_5': 1 - over_2_5,
            'under_3_5': 1 - mc_results.get('over_3_5_probability', 0.3)
        },
        
        # Her iki takım gol atar
        'both_teams_score': {
            'yes': btts,
            'no': 1 - btts
        },
        
        # İlk yarı/Maç sonucu
        'half_time_full_time': {
            '1/1': home_win * 0.6,
            '1/X': home_win * 0.2,
            '1/2': home_win * 0.2,
            'X/1': draw * 0.4,
            'X/X': draw * 0.4,
            'X/2': draw * 0.2,
            '2/1': away_win * 0.1,
            '2/X': away_win * 0.2,
            '2/2': away_win * 0.7
        },
        
        # Handikap
        'handicap': {
            'home_-1': home_win * 0.6,
            'home_-2': home_win * 0.3,
            'away_+1': (draw + away_win) * 0.8,
            'away_+2': (draw + away_win) * 0.9
        },
        
        # Korner sayısı (tahmini)
        'corners': {
            'over_8_5': 0.6,
            'over_9_5': 0.5,
            'over_10_5': 0.4,
            'under_10_5': 0.6
        },
        
        # Kart sayısı (tahmini)
        'cards': {
            'over_2_5': 0.7,
            'over_3_5': 0.5,
            'over_4_5': 0.3,
            'under_4_5': 0.7
        },
        
        # İlk gol
        'first_goal': {
            'home_team': home_win * 1.2,
            'away_team': away_win * 1.2,
            'no_goal': (1 - btts) * 0.1
        },
        
        # Tam skor (en olası 5 skor)
        'exact_score': {
            '1-0': home_win * 0.2,
            '2-1': home_win * 0.25,
            '1-1': draw * 0.4,
            '0-1': away_win * 0.2,
            '1-2': away_win * 0.25
        }
    }
    
    return betting_options

# Servis başlatma
initialize_services()

